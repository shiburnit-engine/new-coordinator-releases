# New Coordinator Plugin Candidate 0.1.0

This candidate establishes the first portable WordPress foundation only.

It includes durable state, structured operational record buckets, Live Work Display, Step Log, and Emergency Stop controls. It does not contact Gemini and does not reuse old Coordinator runtime state.

No candidate becomes Known-Good until functional testing, Security Gate, staging/regression, and promotion pass.
