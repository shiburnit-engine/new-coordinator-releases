<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Runtime Loop Builder compiler foundation.
 *
 * Converts verified structured inputs into a normalized worker envelope.
 * It does not select a provider, dispatch work, or accept its own output.
 */
final class NC_Loop_Builder {
 public static function required_inputs(){
  return array(
   'project_build_identity','feature_and_roadmap_priority','requirements_definition_of_done',
   'governing_rules','rule_enforcement_contract','master_and_local_knowledge',
   'master_and_local_learning','prior_failures','known_good_and_rollback','security_controls',
   'dependencies','allowed_resources_and_scope','viewer_publication_controls',
   'site_time_control_when_applicable'
  );
 }

 private static function present($value){
  if(is_array($value)) return !empty($value);
  if(is_bool($value)||is_numeric($value)) return true;
  return trim((string)$value)!=='';
 }

 public static function compile($input){
  if(!is_array($input)) return new WP_Error('nc_loop_builder_input','Loop Builder requires structured authoritative input.');
  $missing=array();
  foreach(self::required_inputs() as $field){
   if(!array_key_exists($field,$input)||!self::present($input[$field])) $missing[]=$field;
  }
  if($missing) return new WP_Error('nc_loop_builder_not_ready','Loop Builder is NOT_READY: authoritative compiler inputs are missing.',array('missing_inputs'=>$missing));

  if(empty($input['research_completed'])||empty($input['required_loop_structure']))
   return new WP_Error('nc_loop_builder_research_required','Loop Builder is NOT_READY: research must determine the required loop structure before compilation.');

  if(isset($input['learning_normalization'])){
   if(!class_exists('NC_Loop_Builder_Learning'))
    return new WP_Error('nc_loop_builder_learning_seam_unavailable','Loop Builder is NOT_READY: Learning normalization seam is unavailable.');
   $ln=$input['learning_normalization'];
   if(!is_array($ln)||empty($ln['source_path'])||!isset($ln['learning']))
    return new WP_Error('nc_loop_builder_learning_input','Loop Builder is NOT_READY: Learning normalization input is incomplete.');
   $normalized=NC_Loop_Builder_Learning::normalize_for_compile(
    $ln['source_path'],$ln['learning'],$ln['registry']??array(),$ln['scope']??'LOCAL'
   );
   if(is_wp_error($normalized)) return new WP_Error('nc_loop_builder_learning_not_ready','Loop Builder is NOT_READY: Learning normalization failed.',array('learning_error'=>$normalized->get_error_code()));
   $input['master_and_local_learning']=$normalized['records'];
  }

  $envelope=array(
   'project_build_identity'=>$input['project_build_identity'],
   'feature'=>$input['feature_and_roadmap_priority']['feature']??'',
   'roadmap_priority'=>$input['feature_and_roadmap_priority']['roadmap_priority']??'',
   'loop_id'=>$input['loop_id']??'',
   'cycle_id'=>$input['cycle_id']??'',
   'step'=>$input['step']??'',
   'substep'=>$input['substep']??'',
   'bounded_task'=>$input['bounded_task']??'',
   'objective'=>$input['objective']??'',
   'definition_of_done'=>$input['requirements_definition_of_done'],
   'applicable_master_rules'=>$input['applicable_master_rules']??array(),
   'knowledge'=>$input['master_and_local_knowledge'],
   'learning'=>$input['master_and_local_learning'],
   'prior_failures'=>$input['prior_failures'],
   'known_good_patterns'=>$input['known_good_and_rollback'],
   'security_controls'=>$input['security_controls'],
   'authority_limits'=>$input['authority_limits']??'Worker cannot self-accept, change roadmap authority, budget, security controls, or acceptance criteria.',
   'allowed_resources'=>$input['allowed_resources_and_scope']['allowed']??array(),
   'prohibited_boundaries'=>$input['allowed_resources_and_scope']['prohibited']??array(),
   'required_evidence'=>$input['required_evidence']??array(),
   'tests_gates'=>$input['tests_and_acceptance_gates']??array(),
   'failure_procedure'=>$input['failure_and_rebuild_path']??array(),
   'viewer_publication'=>$input['viewer_publication_controls'],
   'site_time_rule_when_applicable'=>$input['site_time_control_when_applicable'],
   'return_control'=>$input['return_control']??'Return result and evidence to New Coordinator for independent validation.',
   'rule_enforcement_records'=>$input['rule_enforcement_records']??array(),
   'applicable_learning_ids'=>$input['applicable_learning_ids']??array(),
   'learning_consumption_records'=>$input['learning_consumption_records']??array(),
   'suggestion_state'=>'USER_APPROVAL_REQUIRED',
   'worker_may_self_accept'=>false
  );

  $validation=NC_Instruction_Gate::validate($envelope);
  if(is_wp_error($validation)) return new WP_Error('nc_loop_builder_not_ready','Loop Builder compiled output failed the worker instruction gate.',array('gate_error'=>$validation->get_error_code(),'gate_data'=>$validation->get_error_data()));

  return array(
   'ready'=>true,
   'compiler_id'=>'NEW-COORDINATOR-LOOP-BUILDER',
   'required_loop_structure'=>$input['required_loop_structure'],
   'worker_instruction_envelope'=>$envelope,
   'independent_validation_required'=>true,
   'compiler_may_accept'=>false,
   'compiled_utc'=>gmdate('c')
  );
 }
}
