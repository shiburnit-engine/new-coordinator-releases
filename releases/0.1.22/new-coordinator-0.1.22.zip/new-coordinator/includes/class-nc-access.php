<?php
if (!defined('ABSPATH')) { exit; }

final class NC_Access {
    const OPTION = 'new_coordinator_access_v1';

    public static function defaults() {
        return array(
            'grants' => array(),
            'history_user_ids' => array(),
            'history_users' => array(),
        );
    }

    public static function data() {
        return wp_parse_args((array) get_option(self::OPTION, array()), self::defaults());
    }

    public static function owner_user_id() {
        $setup = NC_Owner_Setup::state();
        return $setup['status'] === 'CONFIRMED' ? (int) $setup['confirmed_owner_user_id'] : 0;
    }

    public static function level($user_id = 0) {
        $user_id = $user_id ? (int) $user_id : get_current_user_id();
        if (!$user_id) return 'none';
        if (self::owner_user_id() === $user_id) return 'owner';

        $data = self::data();
        $grants = (array) $data['grants'];
        $level = isset($grants[$user_id]) ? sanitize_key($grants[$user_id]) : 'none';
        return in_array($level, array('operator', 'view_only'), true) ? $level : 'none';
    }

    public static function can_view($user_id = 0) {
        return in_array(self::level($user_id), array('owner', 'operator', 'view_only'), true);
    }

    public static function can_operate($user_id = 0) {
        return in_array(self::level($user_id), array('owner', 'operator'), true);
    }

    public static function is_owner($user_id = 0) {
        return self::level($user_id) === 'owner';
    }

    public static function grant($user_id, $level) {
        if (!self::is_owner()) return new WP_Error('nc_access_owner_only', 'Only the Coordinator owner can change access.');
        $user_id = (int) $user_id;
        $level = sanitize_key($level);
        if (!$user_id || self::owner_user_id() === $user_id || !in_array($level, array('operator', 'view_only'), true)) {
            return new WP_Error('nc_access_invalid', 'Invalid Coordinator access change.');
        }
        $user = get_userdata($user_id);
        if (!$user || !in_array('administrator', (array) $user->roles, true)) {
            return new WP_Error('nc_access_admin_required', 'Coordinator access can only be assigned to a WordPress administrator.');
        }
        $data = self::data();
        $data['grants'][$user_id] = $level;
        $history = array_map('intval', (array) $data['history_user_ids']);
        if (!in_array($user_id, $history, true)) $history[] = $user_id;
        $data['history_user_ids'] = array_values(array_unique($history));
        $history_users = (array) $data['history_users'];
        if (!isset($history_users[$user_id])) {
            $history_users[$user_id] = array('user_id'=>$user_id,'username'=>$user->user_login);
        }
        $data['history_users'] = $history_users;
        $old_level = isset(self::data()['grants'][$user_id]) ? sanitize_key(self::data()['grants'][$user_id]) : 'none';
        update_option(self::OPTION, $data, false);
        $event = $old_level === 'none' ? 'ACCESS_GRANTED' : 'ACCESS_ROLE_CHANGED';
        NC_Store::log($event, 'Coordinator access changed for '.$user->user_login.'.', null, null, array('target_user_id'=>$user_id,'target_username'=>$user->user_login,'old_role'=>$old_level,'new_role'=>$level));
        return true;
    }

    public static function revoke($user_id) {
        if (!self::is_owner()) return new WP_Error('nc_access_owner_only', 'Only the Coordinator owner can change access.');
        $user_id = (int) $user_id;
        if (!$user_id || self::owner_user_id() === $user_id) return new WP_Error('nc_access_invalid', 'Owner access cannot be revoked here.');
        $data = self::data();
        $old_level = isset($data['grants'][$user_id]) ? sanitize_key($data['grants'][$user_id]) : 'none';
        unset($data['grants'][$user_id]);
        $history = array_map('intval', (array) $data['history_user_ids']);
        if (!in_array($user_id, $history, true)) $history[] = $user_id;
        $data['history_user_ids'] = array_values(array_unique($history));
        $user = get_userdata($user_id);
        $history_users = (array) $data['history_users'];
        if (!isset($history_users[$user_id])) {
            $history_users[$user_id] = array('user_id'=>$user_id,'username'=>$user?$user->user_login:'user-'.$user_id);
        }
        $data['history_users'] = $history_users;
        update_option(self::OPTION, $data, false);
        $snapshot = isset($history_users[$user_id]['username']) ? $history_users[$user_id]['username'] : ($user?$user->user_login:'user-'.$user_id);
        NC_Store::log('ACCESS_REVOKED', 'Coordinator access revoked. User: '.$snapshot.'.', null, null, array('target_user_id'=>$user_id,'target_username'=>$snapshot,'old_role'=>$old_level));
        return true;
    }

    public static function authorized_users() {
        $ids = array();
        $owner = self::owner_user_id();
        if ($owner) $ids[] = $owner;
        foreach ((array) self::data()['grants'] as $id=>$level) if (in_array($level,array('operator','view_only'),true)) $ids[]=(int)$id;
        return array_values(array_unique($ids));
    }
    public static function audit_users() {
        $data = self::data();
        $users = array();
        foreach (self::authorized_users() as $id) {
            $u = get_userdata($id);
            if ($u) $users[$id] = $u->user_login;
        }
        foreach ((array) $data['history_users'] as $id=>$snapshot) {
            $id = (int) $id;
            if ($id > 0 && !isset($users[$id])) {
                $users[$id] = isset($snapshot['username']) ? sanitize_user($snapshot['username'], true) : 'user-'.$id;
            }
        }
        foreach ((array) $data['history_user_ids'] as $id) {
            $id = (int) $id;
            if ($id > 0 && !isset($users[$id])) {
                $u = get_userdata($id);
                $users[$id] = $u ? $u->user_login : 'user-'.$id;
            }
        }
        return $users;
    }
    public static function audit_user_ids() {
        $data = self::data();
        $ids = self::authorized_users();
        foreach ((array) $data['history_user_ids'] as $id) if ((int)$id > 0) $ids[] = (int)$id;
        return array_values(array_unique($ids));
    }
}
