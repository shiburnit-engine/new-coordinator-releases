<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Durable loop-owned telemetry contract.
 *
 * The Viewer reads these records; it never manufactures execution state.
 */
final class NC_Loop_State {
 const OPTION='new_coordinator_loop_state_v1';
 const STATES=array('CREATED','BUILDING','READY','RUNNING','TESTING','FAILED','LEARNING','RESEARCHING','WAITING','REBUILDING','BLOCKED','STOPPED','COMPLETED');

 public static function activate(){
  if(false===get_option(self::OPTION,false)) add_option(self::OPTION,array(),'','no');
  $master=NC_Store::state();
  $id=sanitize_text_field((string)$master['inner_loop_id']);
  if($id && !self::get($id)){
   self::create(array(
    'loop_id'=>$id,
    'parent_step_id'=>$master['step_id'],
    'parent_loop_id'=>'MAIN',
    'loop_kind'=>'inner',
    'title'=>'Foundation Controls',
    'state'=>'READY',
    'current_position'=>$master['main_loop_stage'],
    'current_action'=>$master['current_action']
   ),'system','new-coordinator');
  }
 }

 public static function all(){ return (array)get_option(self::OPTION,array()); }
 public static function get($loop_id){
  $all=self::all(); $key=sanitize_text_field((string)$loop_id);
  return isset($all[$key]) && is_array($all[$key]) ? $all[$key] : null;
 }
 private static function clean_state($state){
  $state=strtoupper(sanitize_key((string)$state));
  return in_array($state,self::STATES,true)?$state:'READY';
 }
 private static function clean_dependencies($ids){
  $out=array();
  foreach((array)$ids as $id){ $id=sanitize_text_field((string)$id); if($id!==''&&!in_array($id,$out,true)) $out[]=$id; }
  return $out;
 }
 public static function create($data,$actor_type=null,$actor_id=null){
  $id=isset($data['loop_id'])?sanitize_text_field((string)$data['loop_id']):'';
  if($id==='') return new WP_Error('nc_loop_id','Loop ID is required.');
  $all=self::all();
  if(isset($all[$id])) return new WP_Error('nc_loop_exists','Loop already exists.');
  $now=gmdate('c'); $state=self::clean_state($data['state']??'CREATED');
  $row=array(
   'loop_id'=>$id,
   'parent_step_id'=>sanitize_text_field((string)($data['parent_step_id']??'')),
   'parent_loop_id'=>sanitize_text_field((string)($data['parent_loop_id']??'')),
   'loop_kind'=>in_array(($data['loop_kind']??'inner'),array('main','inner'),true)?$data['loop_kind']:'inner',
   'title'=>sanitize_text_field((string)($data['title']??$id)),
   'state'=>$state,
   'current_position'=>sanitize_text_field((string)($data['current_position']??'')),
   'current_action'=>sanitize_text_field((string)($data['current_action']??'')),
   'attempt_count'=>max(0,(int)($data['attempt_count']??0)),
   'restart_count'=>max(0,(int)($data['restart_count']??0)),
   'failure_count'=>max(0,(int)($data['failure_count']??0)),
   'dependency_loop_ids'=>self::clean_dependencies($data['dependency_loop_ids']??array()),
   'created_utc'=>$now,'updated_utc'=>$now,'completed_utc'=>'','final_result'=>''
  );
  $all[$id]=$row; update_option(self::OPTION,$all,false);
  NC_Store::log('LOOP_CREATED','Loop telemetry record created.',$actor_type,$actor_id,array('step_id'=>$row['parent_step_id'],'loop_id'=>$id,'new_state'=>$state));
  return $row;
 }
 public static function transition($loop_id,$new_state,$changes=array(),$actor_type=null,$actor_id=null){
  $id=sanitize_text_field((string)$loop_id); $all=self::all();
  if(!isset($all[$id])) return new WP_Error('nc_loop_missing','Loop does not exist.');
  $row=$all[$id]; $old=$row['state']; $new=self::clean_state($new_state);
  foreach(array('current_position','current_action','final_result') as $k) if(array_key_exists($k,$changes)) $row[$k]=sanitize_text_field((string)$changes[$k]);
  if(array_key_exists('dependency_loop_ids',$changes)) $row['dependency_loop_ids']=self::clean_dependencies($changes['dependency_loop_ids']);
  if(!empty($changes['increment_attempt'])) $row['attempt_count']++;
  if($new==='FAILED' && $old!=='FAILED') $row['failure_count']++;
  if($new==='REBUILDING' && $old!=='REBUILDING') $row['restart_count']++;
  if($new==='COMPLETED') $row['completed_utc']=gmdate('c');
  $row['state']=$new; $row['updated_utc']=gmdate('c'); $all[$id]=$row; update_option(self::OPTION,$all,false);
  NC_Store::log('LOOP_TRANSITION','Loop state changed.',$actor_type,$actor_id,array(
   'step_id'=>$row['parent_step_id'],'loop_id'=>$id,'parent_loop_id'=>$row['parent_loop_id'],
   'old_state'=>$old,'new_state'=>$new,'action'=>$row['current_action']
  ));
  return $row;
 }
 public static function for_step($step_id){
  $out=array(); $step=sanitize_text_field((string)$step_id);
  foreach(self::all() as $row) if(($row['parent_step_id']??'')===$step) $out[]=$row;
  return $out;
 }
 public static function summary($step_id){
  $rows=self::for_step($step_id); $active=0;$complete=0;$fail=0;$restart=0;$building=0;$rebuilding=0;$waiting=0;
  foreach($rows as $r){
   if(($r['state']??'')==='COMPLETED') $complete++; else if(!in_array(($r['state']??''),array('BLOCKED','STOPPED'),true)) $active++;
   if(($r['state']??'')==='BUILDING') $building++;
   if(($r['state']??'')==='REBUILDING') $rebuilding++;
   if(($r['state']??'')==='WAITING') $waiting++;
   $fail+=(int)($r['failure_count']??0); $restart+=(int)($r['restart_count']??0);
  }
  return array('total'=>count($rows),'active'=>$active,'completed'=>$complete,'failures'=>$fail,'restarts'=>$restart,'building'=>$building,'rebuilding'=>$rebuilding,'waiting'=>$waiting);
 }
}
