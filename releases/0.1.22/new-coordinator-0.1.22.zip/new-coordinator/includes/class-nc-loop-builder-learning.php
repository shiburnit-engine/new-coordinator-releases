<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Narrow runtime seam between Learning normalization and Loop Builder.
 * Keeps normalization explicit and independently inspectable.
 */
final class NC_Loop_Builder_Learning {
 public static function normalize_for_compile($source_path,$learning,$registry=array(),$scope='LOCAL'){
  if(!class_exists('NC_Learning_Normalizer'))
   return new WP_Error('nc_learning_normalizer_unavailable','Learning normalizer is unavailable.');
  $normalized=NC_Learning_Normalizer::normalize($source_path,$learning,$registry,$scope);
  if(is_wp_error($normalized)) return $normalized;
  if(empty($normalized['source_preserved'])||empty($normalized['records']))
   return new WP_Error('nc_learning_normalization_not_ready','Normalized Learning is incomplete.');
  return $normalized;
 }
}
