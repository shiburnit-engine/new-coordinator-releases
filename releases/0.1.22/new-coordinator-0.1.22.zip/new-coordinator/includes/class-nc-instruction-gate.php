<?php
if (!defined('ABSPATH')) { exit; }

/**
 * DOD 34 runtime enforcement.
 *
 * Validates the normalized worker instruction envelope before any worker
 * transport is allowed to start. This class does not dispatch a provider.
 */
final class NC_Instruction_Gate {
 const EVENT_REJECTED='WORKER_DISPATCH_REJECTED';

 public static function required_fields(){
  return array(
   'project_build_identity','feature','roadmap_priority','loop_id','cycle_id','step','substep',
   'bounded_task','objective','definition_of_done','applicable_master_rules','knowledge','learning',
   'prior_failures','known_good_patterns','security_controls','authority_limits','allowed_resources',
   'prohibited_boundaries','required_evidence','tests_gates','failure_procedure','viewer_publication',
   'site_time_rule_when_applicable','return_control','rule_enforcement_records','applicable_learning_ids','learning_consumption_records'
  );
 }

 private static function present($value){
  if(is_array($value)) return !empty($value);
  if(is_bool($value)||is_numeric($value)) return true;
  return trim((string)$value)!=='';
 }

 public static function validate($envelope){
  if(!is_array($envelope)) return new WP_Error('nc_instruction_envelope','Instruction envelope must be a structured record.');
  $missing=array();
  foreach(self::required_fields() as $field){
   if(!array_key_exists($field,$envelope)||!self::present($envelope[$field])) $missing[]=$field;
  }
  if($missing) return new WP_Error('nc_instruction_missing_control','Worker dispatch rejected: required instruction controls are missing.',array('missing_controls'=>$missing));
  $records=(array)($envelope['rule_enforcement_records']??array());
  $compiled=array();
  foreach($records as $record){
   if(!is_array($record)) continue;
   $id=trim((string)($record['rule_id']??''));
   if($id==='') continue;
   foreach(array('applicability','enforcement_mode','required_structured_state','required_evidence','gate_or_review','failure_action','acceptance_test') as $field){
    if(!array_key_exists($field,$record)||!self::present($record[$field]))
     return new WP_Error('nc_rule_enforcement_incomplete','Worker dispatch rejected: an applicable governing rule has incomplete enforcement.',array('rule_id'=>$id,'missing_enforcement_field'=>$field));
   }
   if(($record['applicability']??'')==='APPLICABLE') $compiled[$id]=true;
  }
  $applicable=(array)($envelope['applicable_master_rules']??array());
  foreach($applicable as $id){
   $id=trim((string)$id);
   if($id!==''&&!isset($compiled[$id]))
    return new WP_Error('nc_rule_enforcement_missing','Worker dispatch rejected: applicable governing rule has no compiled enforcement.',array('rule_id'=>$id));
  }
  $learning_records=(array)($envelope['learning_consumption_records']??array());
  $consumed=array();
  foreach($learning_records as $record){
   if(!is_array($record)) continue;
   $lesson_id=trim((string)($record['lesson_id']??''));
   if($lesson_id==='') continue;
   foreach(array('applicability','source','evidence_references','incorporated_controls','incorporated_tests','disposition','acceptance_test') as $field){
    if(!array_key_exists($field,$record)||!self::present($record[$field]))
     return new WP_Error('nc_learning_consumption_incomplete','Worker dispatch rejected: an applicable Learning lesson has incomplete consumption evidence.',array('lesson_id'=>$lesson_id,'missing_learning_field'=>$field));
   }
   if(($record['applicability']??'')==='REVIEW_REQUIRED')
    return new WP_Error('nc_learning_review_required','Worker dispatch rejected: Learning applicability still requires review.',array('lesson_id'=>$lesson_id));
   if(($record['applicability']??'')==='APPLICABLE') $consumed[$lesson_id]=true;
  }
  foreach((array)($envelope['applicable_learning_ids']??array()) as $lesson_id){
   $lesson_id=trim((string)$lesson_id);
   if($lesson_id!==''&&!isset($consumed[$lesson_id]))
    return new WP_Error('nc_learning_consumption_missing','Worker dispatch rejected: applicable Learning lesson was not incorporated into controls and tests.',array('lesson_id'=>$lesson_id));
  }
  if(($envelope['suggestion_state']??'USER_APPROVAL_REQUIRED')!=='USER_APPROVAL_REQUIRED')
   return new WP_Error('nc_instruction_suggestion_authority','Worker suggestions must require owner approval.');
  if(!empty($envelope['worker_may_self_accept']))
   return new WP_Error('nc_instruction_self_accept','Worker self-acceptance is prohibited.');
  return array('valid'=>true,'required_field_count'=>count(self::required_fields()),'validated_utc'=>gmdate('c'));
 }

 public static function authorize_dispatch($envelope,$actor_type='system',$actor_id='new-coordinator'){
  $result=self::validate($envelope);
  if(is_wp_error($result)){
   $data=(array)$result->get_error_data(); $missing=(array)($data['missing_controls']??array());
   NC_Store::log(self::EVENT_REJECTED,'Worker dispatch rejected before transport start.',$actor_type,$actor_id,array(
    'loop_id'=>sanitize_text_field((string)($envelope['loop_id']??'')),
    'missing_controls'=>implode(',',$missing),
    'error_code'=>$result->get_error_code(),
    'worker_action_started'=>'false'
   ));
   return $result;
  }
  return $result;
 }
}
