<?php
if (!defined('ABSPATH')) { exit; }

final class NC_Live {
 const NS='new-coordinator/v1';

 public static function boot(){
  add_action('rest_api_init',array(__CLASS__,'routes'));
 }

 public static function routes(){
  register_rest_route(self::NS,'/live',array(
   'methods'=>WP_REST_Server::READABLE,
   'callback'=>array(__CLASS__,'read'),
   'permission_callback'=>array(__CLASS__,'can_read'),
   'args'=>array('after_sequence'=>array('required'=>false,'sanitize_callback'=>'absint','validate_callback'=>function($value){ return is_numeric($value) && (int)$value>=0; }))
  ));
  register_rest_route(self::NS,'/plan/status',array(
   'methods'=>WP_REST_Server::EDITABLE,
   'callback'=>array(__CLASS__,'set_plan_status'),
   'permission_callback'=>array(__CLASS__,'can_operate'),
   'args'=>array(
    'step_id'=>array('required'=>true,'sanitize_callback'=>'sanitize_text_field'),
    'substep_id'=>array('required'=>true,'sanitize_callback'=>'sanitize_text_field'),
    'status'=>array('required'=>true,'sanitize_callback'=>function($value){ return strtoupper(sanitize_key((string)$value)); })
   )
  ));
 }

 public static function can_read(){
  return NC_Access::can_view();
 }

 public static function can_operate(){
  return NC_Access::can_operate();
 }

 public static function set_plan_status(WP_REST_Request $request){
  $step=sanitize_text_field((string)$request->get_param('step_id'));
  $substep=sanitize_text_field((string)$request->get_param('substep_id'));
  $status=strtoupper(sanitize_key((string)$request->get_param('status')));
  $allowed=array('NOT_STARTED','ACTIVE','WAITING','FAILED','REBUILDING','TESTING','COMPLETED');
  if(!in_array($status,$allowed,true)) return new WP_Error('nc_plan_status_invalid','Invalid plan status.',array('status'=>400));
  $result=NC_Plan_State::set_status($step,$substep,$status,null,null);
  if(is_wp_error($result)) return $result;
  return rest_ensure_response(array('ok'=>true,'plan'=>NC_Plan_State::projection($step)));
 }

 private static function event_id($entry,$index){
  return hash('sha256',wp_json_encode(array($index,$entry['utc']??'',$entry['type']??'',$entry['actor_type']??'',$entry['actor_id']??'',$entry['message']??'')));
 }

 private static function feature_projection(){
  // RM-011 / RM-020 / RM-035: packaged read-only projection generated from Master Roadmap authority.
  $path=dirname(__DIR__).'/data/feature-projection.json';
  $raw=is_readable($path)?file_get_contents($path):'';
  $data=$raw?json_decode($raw,true):null;
  $rows=is_array($data)&&isset($data['features'])&&is_array($data['features'])?$data['features']:array();
  $completed=0; $current=null; $selected=NC_Store::current_feature(); $selected_id=$selected['feature_id']??'';
  foreach($rows as $row){
   if(($row['status']??'')==='COMPLETED') $completed++;
   if($selected_id!=='' && ($row['feature_id']??'')===$selected_id) $current=$row;
  }
  return array('total'=>count($rows),'completed'=>$completed,'current'=>$current,'selected_feature_id'=>$selected_id,'selection_valid'=>$current!==null,'source'=>'packaged_feature_projection');
 }

 public static function projection($after_sequence=null){
  $state=NC_Store::state();
  $step=sanitize_text_field((string)$state['step_id']);
  $loops=NC_Loop_State::for_step($step);
  $by_id=array();
  foreach(NC_Loop_State::all() as $row) $by_id[$row['loop_id']]=$row['state'];

  foreach($loops as &$row){
   $deps=array();
   foreach((array)$row['dependency_loop_ids'] as $id) $deps[]=array('loop_id'=>$id,'state'=>$by_id[$id]??'UNKNOWN');
   $row['dependencies']=$deps;
  }
  unset($row);

  $logs=array(); $step_summaries=array();
  $incremental=$after_sequence!==null; $after=$incremental?max(0,(int)$after_sequence):0;
  foreach(NC_Store::log_entries() as $i=>$entry){
   $event_step=sanitize_text_field((string)($entry['step_id']??'LEGACY_UNASSIGNED'));
   if(empty($entry['event_id'])) $entry['event_id']=self::event_id($entry,$i);
   $entry['step_id']=$event_step;
   $entry['display_time']=NC_Store::display_time($entry['utc']??'');
   $seq=(int)($entry['sequence']??0);
   if((!$incremental) || ($seq>0 && $seq>$after)) $logs[]=$entry;
   if(!isset($step_summaries[$event_step])) $step_summaries[$event_step]=array('step_id'=>$event_step,'event_count'=>0,'latest_utc'=>'');
   $step_summaries[$event_step]['event_count']++;
   $step_summaries[$event_step]['latest_utc']=$entry['utc']??$step_summaries[$event_step]['latest_utc'];
  }

  return array(
   'server_utc'=>gmdate('c'),
   'server_display_time'=>NC_Store::display_time(gmdate('c')),
   'main'=>array(
    'cycle'=>(int)($state['main_loop_cycle']??1),
    'stage'=>$state['main_loop_stage'],
    'step_id'=>$step,
    'inner_loop_id'=>$state['inner_loop_id'],
    'current_action'=>$state['current_action'],
    'progress'=>$state['progress'],
    'status'=>$state['status'],
    'blocker'=>$state['blocker'],
    'known_good_build'=>$state['known_good_build'],
    'emergency_stop'=>(bool)$state['emergency_stop'],
    'updated_utc'=>$state['updated_utc']
   ),
   'summary'=>NC_Loop_State::summary($step),
   'features'=>self::feature_projection(),
   'plan'=>NC_Plan_State::projection($step),
   'loops'=>$loops,
   'step_summaries'=>array_values($step_summaries),
   'log_cursor'=>(int)get_option(NC_Store::LOG_SEQUENCE,0),
   'logs'=>$logs
  );
 }

 public static function read(WP_REST_Request $request){
  $after=$request->has_param('after_sequence')?(int)$request->get_param('after_sequence'):null;
  $response=rest_ensure_response(self::projection($after));
  $response->header('Cache-Control','no-store, no-cache, must-revalidate, private, max-age=0');
  $response->header('Pragma','no-cache');
  $response->header('Expires','Wed, 11 Jan 1984 05:00:00 GMT');
  return $response;
 }
}
