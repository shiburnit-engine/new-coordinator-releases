<?php
if (!defined('ABSPATH')) { exit; }

final class NC_Acceptance {
 const NS='new-coordinator/v1';

 public static function boot(){
  add_action('rest_api_init',array(__CLASS__,'routes'));
 }

 public static function routes(){
  register_rest_route(self::NS,'/acceptance/plan-revision-v2',array(
   'methods'=>WP_REST_Server::CREATABLE,
   'callback'=>array(__CLASS__,'plan_revision_v2'),
   'permission_callback'=>array(__CLASS__,'can_run')
  ));
 }

 public static function can_run(WP_REST_Request $request){
  if(!NC_Access::is_owner()) return false;
  $nonce=(string)$request->get_header('X-WP-Nonce');
  return $nonce!=='' && (bool)wp_verify_nonce($nonce,'wp_rest');
 }

 public static function plan_revision_v2(){
  $before=NC_Plan_State::get('NC-001');
  $before_revision=(int)($before['revision']??0);
  $before_history=count((array)($before['history']??array()));

  $row=NC_Plan_State::revise_nc001_v2();
  if(is_wp_error($row)) return $row;

  $after=NC_Plan_State::get('NC-001');
  $after_revision=(int)($after['revision']??0);
  $after_history=count((array)($after['history']??array()));

  return rest_ensure_response(array(
   'accepted'=>true,
   'before_revision'=>$before_revision,
   'after_revision'=>$after_revision,
   'before_history_count'=>$before_history,
   'after_history_count'=>$after_history,
   'request_key'=>(string)($after['revision_request_key']??''),
   'substep_count'=>count((array)($after['substeps']??array())),
   'replay_noop'=>($before_revision===$after_revision && $before_history===$after_history)
  ));
 }
}
