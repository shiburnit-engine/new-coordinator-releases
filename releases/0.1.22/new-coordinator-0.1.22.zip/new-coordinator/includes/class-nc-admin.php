<?php
if (!defined('ABSPATH')) { exit; }
final class NC_Admin {
 public static function boot(){ add_action('admin_menu',array(__CLASS__,'menu')); add_action('admin_enqueue_scripts',array(__CLASS__,'assets')); add_action('admin_post_nc_emergency_stop',array(__CLASS__,'stop')); add_action('admin_post_nc_continue',array(__CLASS__,'resume')); add_action('admin_post_nc_owner_send_code',array(__CLASS__,'send_owner_code')); add_action('admin_post_nc_owner_confirm',array(__CLASS__,'confirm_owner')); add_action('admin_post_nc_access_apply',array(__CLASS__,'access_apply')); add_action('admin_post_nc_run_revision_test',array(__CLASS__,'run_revision_test')); add_action('admin_post_nc_save_public_key',array(__CLASS__,'save_public_key')); add_action('admin_post_nc_delete_public_key',array(__CLASS__,'delete_public_key')); add_action('admin_post_nc_generate_named_key_pair',array(__CLASS__,'generate_named_key_pair')); add_action('admin_post_nc_generate_private_key',array(__CLASS__,'generate_private_key')); }
 public static function assets($hook){
  if($hook!=='toplevel_page_new-coordinator' || NC_Owner_Setup::is_locked() || !NC_Access::can_view()) return;
  wp_enqueue_script('nc-live-viewer',plugins_url('../assets/nc-live-viewer.js',__FILE__),array(),defined('NC_VERSION')?NC_VERSION:'0.1.1-candidate',true);
  wp_localize_script('nc-live-viewer','NCLive',array('url'=>rest_url('new-coordinator/v1/live'),'nonce'=>wp_create_nonce('wp_rest'),'interval'=>3000));
 }
 private static function is_proposed_owner(){
  $setup=NC_Owner_Setup::state();
  return get_current_user_id()>0 && (int)$setup['proposed_owner_user_id']===get_current_user_id();
 }
 public static function menu(){
  if(NC_Owner_Setup::is_locked() && !self::is_proposed_owner()) return;
  if(!NC_Owner_Setup::is_locked() && !NC_Access::can_view()) return;
  add_menu_page('New Coordinator','New Coordinator','read','new-coordinator',array(__CLASS__,'render'),'dashicons-controls-repeat',3);
 }
 public static function send_owner_code(){
  if(!current_user_can('manage_options') || !self::is_proposed_owner() || !NC_Owner_Setup::is_locked()) wp_die('Not authorized.');
  check_admin_referer('nc_owner_send_code');
  $result=NC_Owner_Setup::request_verification_code();
  $key=is_wp_error($result)?'nc_owner_error':'nc_owner_sent';
  $value=is_wp_error($result)?$result->get_error_message():'1';
  wp_safe_redirect(add_query_arg($key,rawurlencode($value),admin_url('admin.php?page=new-coordinator'))); exit;
 }
 public static function confirm_owner(){
  if(!current_user_can('manage_options') || !self::is_proposed_owner() || !NC_Owner_Setup::is_locked()) wp_die('Not authorized.');
  check_admin_referer('nc_owner_confirm');
  $code=isset($_POST['nc_owner_code'])?sanitize_text_field(wp_unslash($_POST['nc_owner_code'])):'';
  $result=NC_Owner_Setup::confirm_with_code($code);
  if(is_wp_error($result)){
   wp_safe_redirect(add_query_arg('nc_owner_error',rawurlencode($result->get_error_message()),admin_url('admin.php?page=new-coordinator'))); exit;
  }
  wp_safe_redirect(add_query_arg('nc_owner_confirmed','1',admin_url('admin.php?page=new-coordinator'))); exit;
 }

 private static function key_copy_field($label,$value,$id){
  echo '<p><label for="'.esc_attr($id).'"><strong>'.esc_html($label).'</strong></label></p><div style="display:flex;gap:8px;max-width:900px"><input id="'.esc_attr($id).'" type="text" readonly value="'.esc_attr($value).'" style="width:100%;font-family:monospace"><button type="button" class="button" onclick="navigator.clipboard.writeText(document.getElementById(\''.esc_js($id).'\').value);this.textContent=\'Copied\';">Copy</button></div>';
 }
 private static function public_key_registry(){
  $rows=get_option('new_coordinator_public_keys_v1',array());
  return is_array($rows)?$rows:array();
 }
 public static function generate_private_key(){
  if(!NC_Access::is_owner()) wp_die('Not authorized.');
  check_admin_referer('nc_generate_private_key');
  $bytes=isset($_POST['key_bytes'])?(int)$_POST['key_bytes']:32;
  $key=NC_Key_Generator::generate_secret($bytes);
  if(is_wp_error($key)) wp_die(esc_html($key->get_error_message()));
  nocache_headers();
  echo '<div class="wrap"><h1>New Coordinator — Generated Private Key</h1><div class="notice notice-warning"><p>Copy this key now. Coordinator does not save it.</p></div>';
  self::key_copy_field('Private key',$key['private_key_base64'],'nc-generated-private-key');
  echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=keys')).'">Return to Keys</a></p></div>'; exit;
 }
 public static function generate_named_key_pair(){
  if(!NC_Access::is_owner()) wp_die('Not authorized.');
  check_admin_referer('nc_generate_named_key_pair');
  $name=isset($_POST['key_name'])?sanitize_text_field(wp_unslash($_POST['key_name'])):'';
  $purpose=isset($_POST['key_purpose'])?sanitize_text_field(wp_unslash($_POST['key_purpose'])):'';
  $secret_ref=isset($_POST['secret_reference'])?sanitize_text_field(wp_unslash($_POST['secret_reference'])):'';
  if($name==='') wp_die('Key name is required.');
  $rows=self::public_key_registry();
  foreach($rows as $existing) if(strcasecmp(trim((string)($existing['name']??'')),trim($name))===0) wp_die('That public key name is already in use.');
  $key=NC_Key_Generator::generate_ed25519();
  if(is_wp_error($key)) wp_die(esc_html($key->get_error_message()));
  $public=$key['public_key_base64']; $decoded=base64_decode($public,true); $id=substr(hash('sha256',$public),0,16);
  $rows[$id]=array('id'=>$id,'name'=>$name,'purpose'=>$purpose,'algorithm'=>'Ed25519','public_key_base64'=>$public,'fingerprint'=>hash('sha256',$decoded),'secret_reference'=>$secret_ref,'status'=>'ACTIVE','created_utc'=>gmdate('c'));
  update_option('new_coordinator_public_keys_v1',$rows,false);
  NC_Store::log('PUBLIC_KEY_SAVED','Owner generated a named Ed25519 pair and saved only its public verification key. Private key material was not persisted.',null,null,array('key_id'=>$id,'key_name'=>$name,'fingerprint'=>$rows[$id]['fingerprint']));
  nocache_headers();
  echo '<div class="wrap nc-generated-key"><style>.nc-generated-key{font-size:18px;line-height:1.5;max-width:1000px}.nc-generated-key h1{font-size:30px;line-height:1.2}.nc-generated-key input{font-size:17px!important;min-height:48px;width:min(100%,820px)}.nc-generated-key .button{font-size:17px!important;min-height:44px;padding:6px 16px!important;margin:6px 0}.nc-generated-key label,.nc-generated-key strong{font-size:18px}@media(max-width:782px){.nc-generated-key{font-size:19px;padding:8px}.nc-generated-key h1{font-size:28px}.nc-generated-key input{display:block;width:100%;font-size:16px!important;margin-bottom:6px}.nc-generated-key .button{font-size:18px!important;min-height:48px}}</style><h1>New Coordinator — Generated Key Pair</h1><div class="notice notice-success"><p>Public key saved as <strong>'.esc_html($name).'</strong>. Copy the private key now; Coordinator will not store it.</p></div>';
  self::key_copy_field('Private key',$key['private_key_base64'],'nc-private-key-once');
  self::key_copy_field('Public key',$public,'nc-public-key-generated');
  echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=keys')).'">Return to Keys</a></p></div>'; exit;
 }
 public static function delete_public_key(){
  if(!NC_Access::is_owner()) wp_die('Not authorized.');
  $id=isset($_POST['key_id'])?sanitize_key(wp_unslash($_POST['key_id'])):'';
  check_admin_referer('nc_delete_public_key_'.$id);
  $rows=self::public_key_registry();
  if(isset($rows[$id])){ $name=$rows[$id]['name']??$id; unset($rows[$id]); update_option('new_coordinator_public_keys_v1',$rows,false); NC_Store::log('PUBLIC_KEY_REMOVED','Owner removed a public verification key record.',null,null,array('key_id'=>$id,'key_name'=>$name)); }
  wp_safe_redirect(admin_url('admin.php?page=new-coordinator&tab=keys')); exit;
 }
 public static function render_keys(){
  try {
   if(!NC_Access::is_owner()) wp_die('Not authorized.'); nocache_headers();
   echo '<div class="wrap"><h1>New Coordinator</h1><nav class="nav-tab-wrapper"><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator')).'">Coordinator</a><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=log')).'">Log</a><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=access')).'">Access</a><a class="nav-tab nav-tab-active" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=keys')).'">Keys</a></nav>';
   echo '<style>.nc-key-subtabs{display:flex;gap:6px;margin:18px 0}.nc-key-panel{display:none}.nc-key-panel.is-active{display:block}</style><div class="nc-key-subtabs"><button type="button" class="button button-primary" data-nc-key-tab="private">Private Key</button><button type="button" class="button" data-nc-key-tab="pair">Key Pair</button><button type="button" class="button" data-nc-key-tab="find">Find Public Key</button></div><div id="nc-key-private" class="nc-key-panel is-active">';
   echo '<h2>Generate Private Key</h2><p>For credentials that do not need a public key. The generated value is displayed once and never stored by Coordinator.</p><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="nc_generate_private_key">'; wp_nonce_field('nc_generate_private_key'); echo '<label for="nc-key-bytes"><strong>Strength</strong></label> <select id="nc-key-bytes" name="key_bytes"><option value="32">256-bit</option><option value="48">384-bit</option><option value="64">512-bit</option></select> <button class="button button-primary" type="submit">Generate Private Key</button></form><hr>';
   echo '</div><div id="nc-key-pair" class="nc-key-panel"><h2>Generate Key Pair</h2><p>Enter the identifying information first. Coordinator then generates a matched Ed25519 pair, automatically saves only the public key, and displays the private key once for copying.</p>';
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="nc_generate_named_key_pair">'; wp_nonce_field('nc_generate_named_key_pair');
   echo '<table class="form-table"><tr><th><label for="nc-key-name">Name</label></th><td><input id="nc-key-name" name="key_name" class="regular-text" required></td></tr><tr><th><label for="nc-key-purpose">Purpose</label></th><td><input id="nc-key-purpose" name="key_purpose" class="regular-text"></td></tr><tr><th><label for="nc-secret-ref">Private-key destination/reference</label></th><td><input id="nc-secret-ref" name="secret_reference" class="regular-text"><p class="description">Reference only. Never paste the private key here.</p></td></tr></table><button class="button button-primary" type="submit">Generate Key Pair</button></form>';
   $rows=self::public_key_registry();
   echo '</div><div id="nc-key-find" class="nc-key-panel"><h2>Find Public Key</h2><p>Paste the complete saved key name. Only an exact match is returned.</p><p><input id="nc-key-search" type="search" class="regular-text" placeholder="Paste exact key name"> <button class="button" type="button" onclick="var q=document.getElementById(\'nc-key-search\').value.trim().toLowerCase(),found=false;document.querySelectorAll(\'.nc-saved-public-key\').forEach(function(el){var hit=el.dataset.keyName===q;el.style.display=hit?\'block\':\'none\';if(hit)found=true;});document.getElementById(\'nc-key-not-found\').style.display=found?\'none\':\'block\';">Find Key</button></p><p id="nc-key-not-found" style="display:none"><strong>Public key not found.</strong></p>';
   foreach($rows as $row){ echo '<div class="nc-saved-public-key" data-key-name="'.esc_attr(strtolower(trim($row['name']))).'" style="display:none;max-width:900px;border:1px solid #c3c4c7;background:#fff;padding:14px;margin:10px 0">'; self::key_copy_field('Public key',$row['public_key_base64'],'nc-found-key-'.$row['id']); echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" onsubmit="return confirm(\'Delete this saved public key? This cannot be undone.\');"><input type="hidden" name="action" value="nc_delete_public_key"><input type="hidden" name="key_id" value="'.esc_attr($row['id']).'">'; wp_nonce_field('nc_delete_public_key_'.$row['id']); echo '<button class="button button-secondary" type="submit">Delete Public Key</button></form></div>'; }
   echo '</div>';    echo '<script>(function(){var buttons=document.querySelectorAll("[data-nc-key-tab]"),panels=document.querySelectorAll(".nc-key-panel");buttons.forEach(function(btn){btn.addEventListener("click",function(){var target=btn.getAttribute("data-nc-key-tab");buttons.forEach(function(b){b.classList.remove("button-primary");});panels.forEach(function(p){p.classList.remove("is-active");});btn.classList.add("button-primary");document.getElementById("nc-key-"+target).classList.add("is-active");});});})();</script>';

  } catch (Throwable $e) { echo '<div class="wrap"><h1>New Coordinator — Keys Diagnostic</h1><div class="notice notice-error"><p><strong>Keys page failure:</strong> '.esc_html(get_class($e).' — '.$e->getMessage()).'</p></div><p>No key material was saved or logged by this diagnostic path.</p></div>'; }
 }
 public static function render_access(){
  if(!NC_Access::is_owner()) wp_die('Not authorized.');
  $target=isset($_GET['user_id'])?(int)$_GET['user_id']:0;
  $intent=isset($_GET['intent'])?sanitize_key(wp_unslash($_GET['intent'])):'';
  $role=isset($_GET['role'])?sanitize_key(wp_unslash($_GET['role'])):'';
  if($intent==='grant' && !in_array($role,array('operator','view_only'),true)) wp_die('Invalid access role.');
  if($target && in_array($intent,array('grant','revoke'),true)){
   $u=get_userdata($target); if(!$u) wp_die('User not found.');
   echo '<div class="wrap"><h1>Confirm Coordinator Access</h1><p>Account: <strong>'.esc_html($u->user_login).'</strong></p>';
   if($intent==='revoke') echo '<p>Revoke this account\'s Coordinator access?</p>';
   else echo '<p>Assign <strong>'.esc_html($role==='operator'?'Operator':'View Only').'</strong> access to this account?</p>';
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="nc_access_apply"><input type="hidden" name="user_id" value="'.esc_attr($target).'"><input type="hidden" name="intent" value="'.esc_attr($intent).'"><input type="hidden" name="role" value="'.esc_attr($role).'">'; wp_nonce_field('nc_access_apply_'.$target); echo '<button class="button button-primary">Confirm</button> <a class="button" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=access')).'">Cancel</a></form></div>'; return;
  }
  $data=NC_Access::data(); $admins=get_users(array('role'=>'administrator','orderby'=>'user_login','order'=>'ASC'));
  echo '<style>.nc-access-wrap{max-width:100%;overflow-x:hidden}.nc-access-table{width:100%;table-layout:fixed}.nc-access-table th,.nc-access-table td{white-space:normal;overflow-wrap:anywhere;word-break:break-word;vertical-align:top}@media(max-width:782px){.nc-access-wrap{margin-right:10px}.nc-access-table,.nc-access-table tbody,.nc-access-table tr,.nc-access-table th,.nc-access-table td{display:block;width:100%!important;box-sizing:border-box}.nc-access-table thead{display:none}.nc-access-table tr{padding:8px 0;border-bottom:1px solid #c3c4c7}}</style><div class="wrap nc-access-wrap"><h1>New Coordinator</h1><nav class="nav-tab-wrapper"><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator')).'">Coordinator</a><a class="nav-tab nav-tab-active" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=access')).'">Access</a></nav><h2>Authorized Users</h2><table class="widefat striped nc-table nc-access-table"><thead><tr><th>Username</th><th>Role</th><th>Actions</th></tr></thead><tbody>';
  $owner_id=NC_Access::owner_user_id(); $owner=get_userdata($owner_id); if($owner) echo '<tr><td>'.esc_html($owner->user_login).'</td><td>Owner</td><td>Protected</td></tr>';
  foreach($admins as $u){ if($u->ID===$owner_id) continue; $level=NC_Access::level($u->ID); if($level==='none') continue; $other=$level==='operator'?'view_only':'operator'; echo '<tr><td>'.esc_html($u->user_login).'</td><td>'.esc_html($level==='operator'?'Operator':'View Only').'</td><td><a href="'.esc_url(add_query_arg(array('page'=>'new-coordinator','tab'=>'access','intent'=>'grant','user_id'=>$u->ID,'role'=>$other),admin_url('admin.php'))).'">Change to '.esc_html($other==='operator'?'Operator':'View Only').'</a> | <a href="'.esc_url(add_query_arg(array('page'=>'new-coordinator','tab'=>'access','intent'=>'revoke','user_id'=>$u->ID),admin_url('admin.php'))).'">Revoke Access</a></td></tr>'; }
  echo '</tbody></table><h2>Available Administrators</h2><table class="widefat striped nc-table nc-access-table"><thead><tr><th>Username</th><th>Assign</th></tr></thead><tbody>';
  foreach($admins as $u){ if($u->ID===$owner_id || NC_Access::level($u->ID)!=='none') continue; echo '<tr><td>'.esc_html($u->user_login).'</td><td><a href="'.esc_url(add_query_arg(array('page'=>'new-coordinator','tab'=>'access','intent'=>'grant','user_id'=>$u->ID,'role'=>'view_only'),admin_url('admin.php'))).'">View Only</a> | <a href="'.esc_url(add_query_arg(array('page'=>'new-coordinator','tab'=>'access','intent'=>'grant','user_id'=>$u->ID,'role'=>'operator'),admin_url('admin.php'))).'">Operator</a></td></tr>'; }
  echo '</tbody></table></div>';
 }
 public static function access_apply(){
  if(!NC_Access::is_owner()) wp_die('Not authorized.');
  $id=isset($_POST['user_id'])?(int)$_POST['user_id']:0; check_admin_referer('nc_access_apply_'.$id);
  $intent=isset($_POST['intent'])?sanitize_key(wp_unslash($_POST['intent'])):''; $role=isset($_POST['role'])?sanitize_key(wp_unslash($_POST['role'])):'';
  if(!in_array($intent,array('grant','revoke'),true)) wp_die('Invalid access action.');
  if($intent==='grant' && !in_array($role,array('operator','view_only'),true)) wp_die('Invalid access role.');
  $result=$intent==='revoke'?NC_Access::revoke($id):NC_Access::grant($id,$role);
  if(is_wp_error($result)) wp_die(esc_html($result->get_error_message()));
  wp_safe_redirect(admin_url('admin.php?page=new-coordinator&tab=access')); exit;
 }
 private static function authorize($action){ if(!NC_Access::can_operate()) wp_die('Not authorized.'); check_admin_referer($action); }
 public static function run_revision_test(){
  if(!NC_Access::is_owner()) wp_die('Not authorized.');
  check_admin_referer('nc_run_revision_test');
  $before=NC_Plan_State::get('NC-001');
  $first=NC_Plan_State::revise_nc001_v2();
  if(is_wp_error($first)) wp_die(esc_html($first->get_error_message()));
  $after_first=NC_Plan_State::get('NC-001');
  $second=NC_Plan_State::revise_nc001_v2();
  if(is_wp_error($second)) wp_die(esc_html($second->get_error_message()));
  $after_second=NC_Plan_State::get('NC-001');
  $pass=((int)($before['revision']??0)===1 && (int)($after_first['revision']??0)===2 && (int)($after_second['revision']??0)===2 && count((array)($after_first['history']??array()))===1 && count((array)($after_second['history']??array()))===1 && count((array)($after_second['substeps']??array()))===16 && ($after_second['revision_request_key']??'')==='nc001-revision-2');
  NC_Store::log($pass?'RUNTIME_ACCEPTANCE_PASS':'RUNTIME_ACCEPTANCE_FAIL',$pass?'RM-023 Revision 2 and replay-no-op runtime acceptance passed.':'RM-023 runtime acceptance assertions failed.',array('feature_id'=>'RM-023','revision_before'=>(int)($before['revision']??0),'revision_after_first'=>(int)($after_first['revision']??0),'revision_after_replay'=>(int)($after_second['revision']??0),'history_after_first'=>count((array)($after_first['history']??array())),'history_after_replay'=>count((array)($after_second['history']??array())),'substep_count'=>count((array)($after_second['substeps']??array()))));
  wp_safe_redirect(add_query_arg('nc_revision_test',$pass?'pass':'fail',admin_url('admin.php?page=new-coordinator'))); exit;
 }

 public static function stop(){ self::authorize('nc_emergency_stop'); NC_Store::update_state(array('emergency_stop'=>true,'progress'=>'STOPPED','current_action'=>'Emergency Stop active. No new actions or promotions may start.')); NC_Store::log('EMERGENCY_STOP','Emergency Stop activated by authorized administrator.'); wp_safe_redirect(admin_url('admin.php?page=new-coordinator')); exit; }
 public static function resume(){ self::authorize('nc_continue'); NC_Store::update_state(array('emergency_stop'=>false,'progress'=>'READY','current_action'=>'Resume from last verified checkpoint; do not blindly repeat interrupted work.')); NC_Store::log('CONTINUE_STEP','Authorized administrator released Emergency Stop.'); wp_safe_redirect(admin_url('admin.php?page=new-coordinator')); exit; }
 public static function render_log(){
  if(!NC_Access::can_view()) wp_die('Not authorized.');
  nocache_headers(); $s=NC_Store::state(); $current=$s['step_id']; $archives=NC_Step_Archive::all(); $events=NC_Store::log_entries();
  // RM-013 / NC-001-09: canonical append-only history is grouped by step even before archival.
  $by_step=array();
  foreach($events as $event){
   $event_step=sanitize_text_field((string)($event['step_id']??'LEGACY_UNASSIGNED'));
   if(!isset($by_step[$event_step])) $by_step[$event_step]=array();
   $by_step[$event_step][]=$event;
  }
  $current_events=$by_step[$current]??array();
  echo '<style>.nc-log-wrap{max-width:100%;overflow-x:hidden}.nc-log-search{width:min(100%,520px)}.nc-step-panel{border:1px solid #c3c4c7;margin:10px 0;background:#fff}.nc-step-panel summary{cursor:pointer;padding:12px;font-weight:600;overflow-wrap:anywhere}.nc-step-body{padding:0 12px 12px}.nc-step-event{padding:8px 0;border-top:1px solid #dcdcde;overflow-wrap:anywhere}.nc-step-event small{display:block}.nc-search-hidden{display:none!important}</style>';
  echo '<div class="wrap nc-log-wrap"><h1>New Coordinator</h1><nav class="nav-tab-wrapper"><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator')).'">Coordinator</a><a class="nav-tab nav-tab-active" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=log')).'">Log</a>'; if(NC_Access::is_owner()) echo '<a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=access')).'">Access</a><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=keys')).'">Keys</a>'; echo '</nav>';
  echo '<h2>Step Logs</h2><p><input id="nc-log-search" class="nc-log-search" type="search" placeholder="Search step, loop, event, username, worker, action or evidence" aria-label="Search Coordinator logs"></p><div id="nc-step-logs">';
  self::render_step_panel($current,'Current step','ACTIVE',$current_events,true);
  $rendered=array($current=>true);
  foreach(array_reverse($archives,true) as $id=>$a){
   self::render_step_panel($id,$a['title']??'Completed step',$a['status']??'COMPLETED',$by_step[$id]??($a['events']??array()),false,$a);
   $rendered[$id]=true;
  }
  foreach(array_reverse($by_step,true) as $id=>$step_events){
   if(isset($rendered[$id])) continue;
   self::render_step_panel($id,$id==='LEGACY_UNASSIGNED'?'Legacy / unassigned history':'Recorded step history','HISTORY',$step_events,false);
  }
  echo '</div></div>';
 }
 private static function render_step_panel($id,$title,$status,$events,$open=false,$archive=array()){
  $search=esc_attr(strtolower($id.' '.$title.' '.$status.' '.wp_json_encode($events).' '.wp_json_encode($archive['evidence_refs']??array())));
  echo '<details class="nc-step-panel" data-step-id="'.esc_attr($id).'" data-current="'.($open?'1':'0').'" data-search="'.$search.'" '.($open?'open':'').'><summary>'.esc_html($id.' — '.$title.' — '.$status).'</summary><div class="nc-step-body">';
  if($archive){ echo '<p><strong>Completed:</strong> '.esc_html(NC_Store::display_time($archive['completed_utc']??'')).'<br><strong>Final result:</strong> '.esc_html($archive['final_result']??'').'<br><strong>Failures:</strong> '.esc_html((string)($archive['failure_occurrences']??0)).' · <strong>Restarts:</strong> '.esc_html((string)($archive['restart_occurrences']??0)).'</p>'; }
  foreach($events as $e){$who=$e['username']??'legacy/unknown';$loop=$e['evidence']['loop_id']??'';$safe=$e['evidence']??array();echo '<div class="nc-step-event" data-event-id="'.esc_attr($e['event_id']??'').'" data-sequence="'.esc_attr($e['sequence']??0).'" data-search="'.esc_attr(strtolower(($e['type']??'').' '.$who.' '.($e['message']??'').' '.$loop.' '.wp_json_encode($safe))).'"><strong>'.esc_html($e['type']??'').'</strong> — '.esc_html($e['message']??'').'<small>'.esc_html(NC_Store::display_time($e['utc']??'').' · '.$who.($loop?' · '.$loop:'')).'</small></div>';}
  if(!$events)echo '<p>No events recorded for this step yet.</p>'; echo '</div></details>';
 }
 public static function render(){
  if(NC_Owner_Setup::is_locked()){
   if(!current_user_can('manage_options')) wp_die('Not authorized.');
   if(!self::is_proposed_owner()) wp_die('Not authorized.');
   $setup=NC_Owner_Setup::state();
   $owner=get_userdata((int)$setup['proposed_owner_user_id']);
   echo '<div class="wrap nc-wrap"><h1>New Coordinator Setup</h1><p><strong>Setup locked.</strong> Operational controls remain unavailable until Coordinator ownership is confirmed.</p>';
   echo '<p>Proposed original owner: <strong>'.esc_html($owner?$owner->user_login:'Unavailable').'</strong></p>';
   if(isset($_GET['nc_owner_sent'])) echo '<div class="notice notice-success"><p>Verification code sent to the registered owner email. It expires in 10 minutes.</p></div>';
   if(isset($_GET['nc_owner_error'])) echo '<div class="notice notice-error"><p>'.esc_html(rawurldecode(sanitize_text_field(wp_unslash($_GET['nc_owner_error'])))).'</p></div>';
   echo '<p><a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=nc_owner_send_code'),'nc_owner_send_code')).'">Send Verification Code</a></p>';
   echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="nc_owner_confirm">';
   wp_nonce_field('nc_owner_confirm');
   echo '<label for="nc-owner-code"><strong>Verification code</strong></label><br><input id="nc-owner-code" name="nc_owner_code" type="text" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required> ';
   echo '<button class="button button-primary" type="submit">Confirm Ownership</button></form></div>';
   return;
  }
  if(!NC_Access::can_view()) wp_die('Not authorized.');
  $tab=isset($_GET['tab'])?sanitize_key(wp_unslash($_GET['tab'])):'coordinator';
  if($tab==='log'){ self::render_log(); return; }
  if($tab==='keys'){ if(!NC_Access::is_owner()) wp_die('Not authorized.'); self::render_keys(); return; }
  if($tab==='access'){
   if(!NC_Access::is_owner()) wp_die('Not authorized.');
   self::render_access(); return;
  }
  nocache_headers();
  $s=NC_Store::state(); $plan=NC_Plan_State::projection($s['step_id']);
  $friendly_status=$s['emergency_stop']?'Stopped':($s['blocker']?'Needs attention':ucwords(strtolower(str_replace('_',' ',(string)$s['progress']))));
  $next_title='Acceptance and close this feature';
  foreach($plan['substeps'] as $item){ if(in_array($item['status'],array('NOT_STARTED','WAITING'),true)){ $next_title=$item['title']; break; } }
  echo '<style>.nc-wrap{max-width:1100px;overflow-x:hidden}.nc-top{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:18px;align-items:center;background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:18px;margin:18px 0}.nc-gauge{height:22px;background:#dcdcde;border-radius:11px;overflow:hidden}.nc-gauge>span{display:block;height:100%;background:#2271b1}.nc-cycle{text-align:center;min-width:130px}.nc-cycle strong{display:block;font-size:28px}.nc-health,.nc-tech{font-size:12px;color:#646970}.nc-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:14px 0}.nc-card{background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:16px;min-width:0;overflow-wrap:anywhere}.nc-card h2{font-size:14px;margin:0 0 7px;color:#50575e}.nc-big{font-size:18px;font-weight:600;margin:0}.nc-controls{margin:18px 0}@media(max-width:782px){.nc-wrap{margin-right:10px}.nc-top,.nc-cards{grid-template-columns:1fr}.nc-cycle{text-align:left}}</style>';
  echo '<div class="wrap nc-wrap"><h1>New Coordinator <small style="font-size:13px;font-weight:400">— '.esc_html($s['project_mode']).'</small></h1>';
  if(isset($_GET['nc_revision_test'])){ $ok=sanitize_key(wp_unslash($_GET['nc_revision_test']))==='pass'; echo '<div class="notice '.($ok?'notice-success':'notice-error').'"><p>'.($ok?'Revision runtime test passed. Revision 2 was applied once and replay was a no-op.':'Revision runtime test failed. Check the Coordinator Log before continuing.').'</p></div>'; }
  echo '<nav class="nav-tab-wrapper"><a class="nav-tab nav-tab-active" href="'.esc_url(admin_url('admin.php?page=new-coordinator')).'">Coordinator</a><a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=log')).'">Log</a>'; if(NC_Access::is_owner()) echo '<a class="nav-tab" href="'.esc_url(admin_url('admin.php?page=new-coordinator&tab=access')).'">Access</a>'; echo '</nav>';
  echo '<section class="nc-top"><div><h2 style="margin-top:0">Current Feature Progress <span id="nc-build-percent">'.esc_html($plan['percent']).'%</span></h2><div id="nc-progress-gauge" class="nc-gauge" role="progressbar" aria-label="Current feature progress" aria-valuemin="0" aria-valuemax="100" aria-valuenow="'.esc_attr($plan['percent']).'"><span id="nc-progress-bar" style="width:'.esc_attr($plan['percent']).'%"></span></div><p id="nc-progress-formula">'.esc_html($plan['completed'].' of '.$plan['total'].' planned steps completed').'</p><span id="nc-live-health" class="nc-health">Connecting…</span></div><div class="nc-cycle"><span>Main Loop Cycle</span><strong id="nc-main-cycle">'.esc_html((string)($s['main_loop_cycle']??1)).'</strong></div></section>';
  echo '<div class="nc-cards"><section class="nc-card"><h2>What We\'re Building</h2><p id="nc-feature-title" class="nc-big">'.esc_html($plan['title']?:'New Coordinator Foundation').'</p><p>Secure foundation needed before Gemini becomes a Coordinator worker.</p><div class="nc-tech">'.esc_html($s['step_id']).'</div></section>';
  echo '<section class="nc-card"><h2>What I\'m Doing Now</h2><p id="nc-current-action" class="nc-big">'.esc_html($s['current_action']).'</p><div id="nc-current-step-tech" class="nc-tech">'.esc_html($s['inner_loop_id']).'</div></section>';
  echo '<section class="nc-card"><h2>Why I\'m Doing It</h2><p>Build and verify the Coordinator foundation safely before connecting Gemini or allowing automated work.</p></section>';
  echo '<section class="nc-card"><h2>What Happens Next</h2><p id="nc-next-action" class="nc-big">'.esc_html($next_title).'</p></section>';
  echo '<section class="nc-card"><h2>Status</h2><p id="nc-friendly-status" class="nc-big">'.esc_html($friendly_status).'</p><p id="nc-status-detail">'.esc_html($s['blocker']?:'No blocker is currently recorded.').'</p></section>';
  echo '<section class="nc-card"><h2>Need Anything From You?</h2><p id="nc-owner-needed" class="nc-big">'.esc_html(($s['blocker']||$s['emergency_stop'])?'Yes':'No').'</p><p id="nc-owner-needed-detail">'.esc_html($s['blocker']?:($s['emergency_stop']?'Emergency Stop is active.':'Coordinator can continue without owner action right now.')).'</p></section>';
  echo '<section class="nc-card"><h2>Current Feature Steps</h2><p id="nc-feature-steps" class="nc-big">'.esc_html($plan['completed'].' of '.$plan['total'].' complete').'</p><p>Only this Feature\'s accepted plan is counted. Future steps are not guessed.</p></section>';
  echo '<section class="nc-card"><h2>Features</h2><p id="nc-feature-counts" class="nc-big">Loading verified Feature registry…</p><p>Counts come from the packaged read-only projection of the Master Roadmap Feature registry.</p></section></div><div class="nc-controls">';
  if(NC_Access::can_operate()){ if(!$s['emergency_stop']) echo '<a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=nc_emergency_stop'),'nc_emergency_stop')).'">Emergency Stop</a>'; else echo '<a class="button button-primary" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=nc_continue'),'nc_continue')).'">Continue Step</a>'; } else echo '<em>View-only access: operational controls are unavailable.</em>';
  if(NC_Access::is_owner() && (int)($plan['revision']??1)<2) echo ' <a class="button" href="'.esc_url(wp_nonce_url(admin_url('admin-post.php?action=nc_run_revision_test'),'nc_run_revision_test')).'">Run Revision Test</a>';
  echo '</div></div>';
 }
}
