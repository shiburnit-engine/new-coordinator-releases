<?php
if (!defined('ABSPATH')) { exit; }

/**
 * RM-035 / NC-001-08 — Feature ownership and searchability contract.
 *
 * Validates packaged Feature manifests and builds a read-only searchable index.
 * The Master Roadmap ledger remains authority; this class never invents status.
 */
final class NC_Feature_Registry {
 const FEATURE_ID_PATTERN='/^RM-[0-9]{3}$/';
 const MANIFEST_FIELDS=array(
  'research','plan','tests','evidence','dependencies','knowledge_refs','learning_refs',
  'implementation_locations','shared_components','ownership_markers'
 );

 public static function root(){ return trailingslashit(NC_DIR).'features'; }

 public static function manifest_path($feature_id){
  $id=strtolower(sanitize_text_field((string)$feature_id));
  return self::root().'/'.$id.'/feature.json';
 }

 public static function load($feature_id){
  $id=strtoupper(sanitize_text_field((string)$feature_id));
  if(!preg_match(self::FEATURE_ID_PATTERN,$id)) return new WP_Error('nc_feature_id','Invalid Feature ID.');
  $path=self::manifest_path($id);
  if(!is_readable($path)) return new WP_Error('nc_feature_manifest_missing','Feature manifest is missing.',array('feature_id'=>$id));
  $data=json_decode((string)file_get_contents($path),true);
  if(!is_array($data)) return new WP_Error('nc_feature_manifest_json','Feature manifest is invalid JSON.',array('feature_id'=>$id));
  return $data;
 }

 public static function validate_manifest($feature_id){
  $id=strtoupper(sanitize_text_field((string)$feature_id));
  $m=self::load($id); if(is_wp_error($m)) return $m;
  $errors=array();
  if(($m['feature_id']??'')!==$id) $errors[]='feature_id_mismatch';
  if(($m['authority']??'')!=='master-loop/roadmap/master-roadmap-ledger.jsonl') $errors[]='authority_mismatch';
  foreach(self::MANIFEST_FIELDS as $field) if(!array_key_exists($field,$m)||!is_array($m[$field])) $errors[]='invalid_'.$field;
  foreach(array('implementation_locations','shared_components','ownership_markers') as $field){
   foreach((array)($m[$field]??array()) as $value) if(!is_string($value)||trim($value)==='') $errors[]='invalid_'.$field.'_entry';
  }
  return array('feature_id'=>$id,'valid'=>empty($errors),'errors'=>array_values(array_unique($errors)),'manifest'=>$m);
 }

 public static function index($feature_ids){
  $rows=array(); $invalid=array();
  foreach((array)$feature_ids as $feature_id){
   $v=self::validate_manifest($feature_id);
   if(is_wp_error($v)){ $invalid[]=$feature_id; continue; }
   if(!$v['valid']) $invalid[]=$feature_id;
   $m=$v['manifest'];
   $rows[]=array(
    'feature_id'=>$v['feature_id'],
    'title'=>sanitize_text_field((string)($m['title']??'')),
    'status'=>sanitize_text_field((string)($m['status']??'')),
    'manifest'=>'features/'.strtolower($v['feature_id']).'/feature.json',
    'research'=>(array)$m['research'],'plan'=>(array)$m['plan'],'tests'=>(array)$m['tests'],
    'evidence'=>(array)$m['evidence'],'dependencies'=>(array)$m['dependencies'],
    'knowledge_refs'=>(array)$m['knowledge_refs'],'learning_refs'=>(array)$m['learning_refs'],
    'implementation_locations'=>(array)$m['implementation_locations'],
    'shared_components'=>(array)$m['shared_components'],'ownership_markers'=>(array)$m['ownership_markers']
   );
  }
  return array('schema_version'=>1,'feature_count'=>count($rows),'valid'=>empty($invalid),'invalid_features'=>array_values($invalid),'features'=>$rows);
 }

 public static function search($index,$query){
  $q=strtolower(trim((string)$query)); if($q==='') return array();
  $out=array();
  foreach((array)($index['features']??array()) as $row){
   $hay=strtolower(wp_json_encode($row));
   if(strpos($hay,$q)!==false) $out[]=$row;
  }
  return $out;
 }
}
