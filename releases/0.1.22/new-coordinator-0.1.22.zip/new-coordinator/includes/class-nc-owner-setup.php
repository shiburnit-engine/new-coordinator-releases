<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Install-time Coordinator ownership bootstrap.
 * Operational authorization is added only after this fail-closed state layer passes review.
 */
final class NC_Owner_Setup {
    const OPTION = 'new_coordinator_owner_setup_v1';

    public static function defaults() {
        return array(
            'status' => 'SETUP_LOCKED',
            'proposed_owner_user_id' => 0,
            'confirmed_owner_user_id' => 0,
            'confirmed_utc' => '',
            'verification_hash' => '',
            'verification_expires_utc' => '',
            'verification_attempts' => 0,
            'verification_last_sent_utc' => '',
            'verification_window_started_utc' => '',
            'verification_send_count' => 0,
        );
    }

    public static function state() {
        return wp_parse_args((array) get_option(self::OPTION, array()), self::defaults());
    }

    public static function detect_proposed_owner() {
        $state = self::state();
        if ((int) $state['proposed_owner_user_id'] > 0 || $state['status'] === 'CONFIRMED') {
            return $state;
        }

        $admins = get_users(array(
            'role'    => 'administrator',
            'orderby' => 'registered',
            'order'   => 'ASC',
            'number'  => 1,
            'fields'  => array('ID', 'user_registered'),
        ));

        if (empty($admins) || empty($admins[0]->ID)) {
            return $state;
        }

        $state['status'] = 'SETUP_LOCKED';
        $state['proposed_owner_user_id'] = (int) $admins[0]->ID;
        update_option(self::OPTION, $state, false);
        return $state;
    }

    public static function request_verification_code() {
        $state = self::detect_proposed_owner();
        $user_id = get_current_user_id();
        if (!$user_id || (int) $state['proposed_owner_user_id'] !== $user_id || $state['status'] === 'CONFIRMED') {
            return new WP_Error('nc_owner_not_allowed', 'Ownership verification is not available for this account.');
        }

        $now = time();
        $window_started = !empty($state['verification_window_started_utc']) ? strtotime($state['verification_window_started_utc']) : 0;
        if (!$window_started || ($now - $window_started) >= 3600) {
            $state['verification_window_started_utc'] = gmdate('c', $now);
            $state['verification_send_count'] = 0;
        }
        if ((int) $state['verification_send_count'] >= 5) {
            NC_Store::log('OWNER_VERIFICATION_RATE_LIMITED', 'Ownership verification email request blocked by hourly rate limit.');
            return new WP_Error('nc_owner_hourly_limit', 'Too many verification emails were requested. Please try again later.');
        }

        $last_sent = !empty($state['verification_last_sent_utc']) ? strtotime($state['verification_last_sent_utc']) : 0;
        if ($last_sent && (time() - $last_sent) < 60) {
            NC_Store::log('OWNER_VERIFICATION_RATE_LIMITED', 'Ownership verification email request blocked by resend cooldown.');
            return new WP_Error('nc_owner_rate_limited', 'Please wait before requesting another verification code.');
        }

        $owner = get_userdata($user_id);
        if (!$owner || !is_email($owner->user_email)) {
            NC_Store::log('OWNER_VERIFICATION_SEND_FAILED', 'Ownership verification email is unavailable for the proposed owner account.');
            return new WP_Error('nc_owner_email_unavailable', 'The proposed owner does not have a valid registered email address.');
        }

        $code = (string) random_int(100000, 999999);
        $state['verification_hash'] = wp_hash_password($code);
        $state['verification_expires_utc'] = gmdate('c', time() + 600);
        $state['verification_attempts'] = 0;
        $state['verification_last_sent_utc'] = gmdate('c');
        $state['verification_send_count'] = (int) $state['verification_send_count'] + 1;
        update_option(self::OPTION, $state, false);

        $sent = wp_mail(
            $owner->user_email,
            'New Coordinator ownership verification',
            'Your New Coordinator ownership verification code is: ' . $code . "\n\nThis code expires in 10 minutes. If you did not request it, do not share or use it."
        );

        if (!$sent) {
            $state['verification_hash'] = '';
            $state['verification_expires_utc'] = '';
            update_option(self::OPTION, $state, false);
            NC_Store::log('OWNER_VERIFICATION_SEND_FAILED', 'Ownership verification email could not be sent.');
            return new WP_Error('nc_owner_email_failed', 'WordPress could not send the verification email.');
        }

        NC_Store::log('OWNER_VERIFICATION_SENT', 'Ownership verification email sent to the proposed owner.');
        return true;
    }

    public static function confirm_with_code($submitted_code) {
        $state = self::state();
        $user_id = get_current_user_id();
        if (!$user_id || (int) $state['proposed_owner_user_id'] !== $user_id || $state['status'] === 'CONFIRMED') {
            return new WP_Error('nc_owner_not_allowed', 'Ownership confirmation is not available for this account.');
        }

        $code = preg_replace('/\D+/', '', (string) $submitted_code);
        if (strlen($code) !== 6 || empty($state['verification_hash']) || empty($state['verification_expires_utc'])) {
            return new WP_Error('nc_owner_code_invalid', 'The verification code is invalid.');
        }

        if ((int) $state['verification_attempts'] >= 5) {
            $state['verification_hash'] = '';
            $state['verification_expires_utc'] = '';
            update_option(self::OPTION, $state, false);
            NC_Store::log('OWNER_VERIFICATION_LOCKED', 'Ownership verification invalidated after too many attempts.');
            return new WP_Error('nc_owner_attempt_limit', 'Too many verification attempts. Request a new code.');
        }

        $expires = strtotime($state['verification_expires_utc']);
        if (!$expires || time() > $expires) {
            $state['verification_hash'] = '';
            $state['verification_expires_utc'] = '';
            update_option(self::OPTION, $state, false);
            NC_Store::log('OWNER_VERIFICATION_EXPIRED', 'Ownership verification code expired and was invalidated.');
            return new WP_Error('nc_owner_code_expired', 'The verification code has expired.');
        }

        $state['verification_attempts'] = (int) $state['verification_attempts'] + 1;
        if (!wp_check_password($code, $state['verification_hash'])) {
            if ((int) $state['verification_attempts'] >= 5) {
                $state['verification_hash'] = '';
                $state['verification_expires_utc'] = '';
            }
            update_option(self::OPTION, $state, false);
            NC_Store::log('OWNER_VERIFICATION_FAILED', 'Ownership verification code was rejected.', null, null, array('attempts'=>$state['verification_attempts']));
            return new WP_Error('nc_owner_code_wrong', 'The verification code is incorrect.');
        }

        $state['status'] = 'CONFIRMED';
        $state['confirmed_owner_user_id'] = $user_id;
        $state['confirmed_utc'] = gmdate('c');
        $state['verification_hash'] = '';
        $state['verification_expires_utc'] = '';
        $state['verification_attempts'] = 0;
        $state['verification_window_started_utc'] = '';
        $state['verification_send_count'] = 0;
        update_option(self::OPTION, $state, false);

        NC_Store::log('OWNER_CONFIRMED', 'Original Coordinator owner confirmed by email verification.');
        NC_Store::update_state(array(
            'status' => 'FOUNDATION_SPECIFIED_NOT_IMPLEMENTED',
            'progress' => 'READY',
            'current_action' => 'Coordinator owner confirmed. Continue foundation verification.'
        ));
        return true;
    }

    public static function is_locked() {
        return self::state()['status'] !== 'CONFIRMED';
    }
}
