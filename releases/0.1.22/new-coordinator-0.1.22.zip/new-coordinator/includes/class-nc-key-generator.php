<?php
if (!defined('ABSPATH')) { exit; }

final class NC_Key_Generator {
    public static function available() {
        return function_exists('sodium_crypto_sign_keypair')
            && function_exists('sodium_crypto_sign_secretkey')
            && function_exists('sodium_crypto_sign_publickey')
            && function_exists('sodium_crypto_sign_detached')
            && function_exists('sodium_crypto_sign_verify_detached');
    }

    public static function generate_ed25519() {
        if (!self::available()) {
            return new WP_Error('nc_sodium_unavailable', 'Ed25519 generation requires PHP Sodium support.');
        }
        $private = null;
        try {
            $pair = sodium_crypto_sign_keypair();
            $private = sodium_crypto_sign_secretkey($pair);
            $public = sodium_crypto_sign_publickey($pair);
            $probe = random_bytes(32);
            $signature = sodium_crypto_sign_detached($probe, $private);
            if (!sodium_crypto_sign_verify_detached($signature, $probe, $public)) {
                self::wipe($private);
                return new WP_Error('nc_key_self_test_failed', 'Generated Ed25519 key pair failed its sign/verify self-test.');
            }
            $private_b64 = base64_encode($private);
            $public_b64 = base64_encode($public);
            self::wipe($private);
            NC_Store::log('SIGNING_KEY_GENERATED', 'Owner generated and self-tested a new Ed25519 key pair. Key material was not persisted or logged.', null, null, array(
                'algorithm' => 'Ed25519',
                'public_key_fingerprint' => hash('sha256', $public),
            ));
            return array(
                'algorithm' => 'Ed25519',
                'private_key_base64' => $private_b64,
                'public_key_base64' => $public_b64,
                'self_test' => 'PASS',
            );
        } catch (Throwable $e) {
            self::wipe($private);
            NC_Store::log('SIGNING_KEY_GENERATION_FAILED', 'Ed25519 key generation failed safely. No key material was persisted or logged.', 'system', 'new-coordinator', array(
                'error_class' => get_class($e),
                'error_message' => $e->getMessage(),
            ));
            return new WP_Error('nc_key_generation_failed', 'Ed25519 key generation failed: '.$e->getMessage());
        }
    }

    private static function wipe(&$value) {
        if (!is_string($value)) return;
        if (function_exists('sodium_memzero')) {
            try {
                sodium_memzero($value);
                return;
            } catch (Throwable $e) {
                // sodium_compat exposes sodium_memzero() but throws because secure wiping is unavailable in PHP.
            }
        }
        $value = str_repeat("\0", strlen($value));
        unset($value);
    }

    public static function generate_secret($bytes = 32) {
        $bytes = max(16, min(128, (int)$bytes));
        try {
            $raw = random_bytes($bytes);
            $value = base64_encode($raw);
            self::wipe($raw);
            NC_Store::log('PRIVATE_KEY_GENERATED', 'Owner generated a random private key. Key material was not persisted or logged.', null, null, array('encoding' => 'base64', 'bytes' => $bytes));
            return array('private_key_base64' => $value, 'bytes' => $bytes);
        } catch (Throwable $e) {
            return new WP_Error('nc_private_key_generation_failed', 'Private key generation failed: '.$e->getMessage());
        }
    }

    public static function verify_pair($private_b64, $public_b64) {
        if (!self::available()) return false;
        $private = base64_decode((string)$private_b64, true);
        $public = base64_decode((string)$public_b64, true);
        if ($private === false || $public === false || strlen($private) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES || strlen($public) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) return false;
        $probe = random_bytes(32);
        $ok = sodium_crypto_sign_verify_detached(sodium_crypto_sign_detached($probe, $private), $probe, $public);
        self::wipe($private);
        return $ok;
    }
}
