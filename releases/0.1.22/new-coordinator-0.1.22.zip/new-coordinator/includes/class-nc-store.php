<?php
if (!defined('ABSPATH')) { exit; }
final class NC_Store {
 const STATE='new_coordinator_state_v1';
 const LOG='new_coordinator_step_log_v1';
 const RECORDS='new_coordinator_records_v1';
 const LOG_SEQUENCE='new_coordinator_step_log_sequence_v1';
 const CURRENT_FEATURE='new_coordinator_current_feature_v1';
 public static function defaults(){ return array(
  'foundation_spec_version'=>1,'project_mode'=>'NEW_PROJECT','status'=>'FOUNDATION_SPECIFIED_NOT_IMPLEMENTED',
  'objective'=>'Build and prove secure portable Gemini Communicator','main_loop_cycle'=>1,'main_loop_stage'=>'FOUNDATION_BUILD',
  'step_id'=>'NC-001','inner_loop_id'=>'IL-NC-001-FOUNDATION','current_action'=>'Build and verify portable foundation controls',
  'progress'=>'CANDIDATE','blocker'=>'','known_good_build'=>'NOT_YET_CREATED','emergency_stop'=>false,'updated_utc'=>gmdate('c')
 );}
 public static function activate(){
  if(false===get_option(self::STATE,false)) add_option(self::STATE,self::defaults(),'','no');
  if(false===get_option(self::LOG,false)) add_option(self::LOG,array(),'','no');
  if(false===get_option(self::LOG_SEQUENCE,false)) add_option(self::LOG_SEQUENCE,0,'','no');
  if(false===get_option(self::RECORDS,false)) add_option(self::RECORDS,array(
   'research'=>array(),'knowledge'=>array(),'learning'=>array(),'planning'=>array(),'tests'=>array(),'evidence'=>array(),
   'attempts'=>array(),'hypotheses'=>array(),'dependencies'=>array(),'platforms'=>array(),'secrets_metadata'=>array(),
   'variables'=>array(),'chats'=>array(),'checkpoints'=>array()
  ),'','no');
  self::log('PLUGIN_ACTIVATED','New Coordinator candidate activated.','system','new-coordinator');
 }
 public static function state(){ return wp_parse_args((array)get_option(self::STATE,array()),self::defaults()); }
 public static function update_state($changes){
  $s=self::state(); $allowed=array('status','main_loop_stage','step_id','inner_loop_id','current_action','progress','blocker','known_good_build','emergency_stop');
  foreach($allowed as $k) if(array_key_exists($k,$changes)) $s[$k]=is_bool($changes[$k])?$changes[$k]:sanitize_text_field((string)$changes[$k]);
  $s['updated_utc']=gmdate('c'); update_option(self::STATE,$s,false); return $s;
 }
 public static function current_feature(){
  $v=get_option(self::CURRENT_FEATURE,array());
  return is_array($v)?$v:array();
 }
 public static function select_feature($feature_id,$reason=''){
  $id=strtoupper(sanitize_text_field((string)$feature_id));
  if(!preg_match('/^RM-[0-9]{3}$/',$id)) return new WP_Error('invalid_feature_id','Invalid Feature ID.');
  $old=self::current_feature(); if(($old['feature_id']??'')===$id) return $old;
  $row=array('feature_id'=>$id,'selected_utc'=>gmdate('c'),'reason'=>sanitize_text_field((string)$reason));
  update_option(self::CURRENT_FEATURE,$row,false);
  self::log('FEATURE_SELECTED','Current Feature selection changed.','system','new-coordinator',array('feature_id'=>$id,'previous_feature_id'=>$old['feature_id']??'','reason'=>$row['reason']));
  return $row;
 }
 public static function actor(){
  $u=wp_get_current_user();
  if($u && $u->exists()) return array('actor_type'=>'wordpress_user','actor_id'=>(string)$u->ID,'username'=>$u->user_login);
  return array('actor_type'=>'system','actor_id'=>'new-coordinator','username'=>'new-coordinator');
 }
 public static function log($type,$message,$actor_type=null,$actor_id=null,$evidence=array()){
  $log=(array)get_option(self::LOG,array()); $a=self::actor();
  if($actor_type!==null) $a['actor_type']=sanitize_key($actor_type);
  if($actor_id!==null){ $a['actor_id']=sanitize_text_field((string)$actor_id); $a['username']=sanitize_text_field((string)$actor_id); }
  $safe=array(); foreach((array)$evidence as $k=>$v) if(is_scalar($v)||is_null($v)) $safe[sanitize_key($k)]=sanitize_text_field((string)$v);
  $seq=max(0,(int)get_option(self::LOG_SEQUENCE,0))+1;
  update_option(self::LOG_SEQUENCE,$seq,false);
  $state=self::state();
  $step_id=isset($safe['step_id'])&&$safe['step_id']!==''?$safe['step_id']:sanitize_text_field((string)($state['step_id']??''));
  $log[]=array('event_id'=>'nc-event-'.$seq,'sequence'=>$seq,'step_id'=>$step_id,'utc'=>gmdate('c'),'type'=>sanitize_key($type),'actor_type'=>$a['actor_type'],'actor_id'=>$a['actor_id'],
   'username'=>sanitize_user($a['username'],true),'message'=>sanitize_text_field($message),'evidence'=>$safe);
  update_option(self::LOG,$log,false);
 }
 public static function log_entries(){
  $log=(array)get_option(self::LOG,array()); $legacy=0;
  foreach($log as $i=>&$e){
   if(!isset($e['sequence'])){$legacy++;$e['sequence']=-1000000+$legacy;}
   if(empty($e['event_id']))$e['event_id']='legacy-'.hash('sha256',wp_json_encode(array($i,$e['utc']??'',$e['type']??'',$e['message']??'')));
   if(!isset($e['step_id']))$e['step_id']=isset($e['evidence']['step_id'])?sanitize_text_field((string)$e['evidence']['step_id']):'LEGACY_UNASSIGNED';
  } unset($e);
  return $log;
 }
 public static function display_time($utc){
  try { $dt=new DateTimeImmutable($utc,new DateTimeZone('UTC')); $format=trim((string)get_option('date_format').' '.(string)get_option('time_format')); if($format==='') $format='Y-m-d H:i'; return wp_date($format,$dt->getTimestamp(),wp_timezone()); }
  catch(Exception $e){ return sanitize_text_field((string)$utc); }
 }
}
