<?php
if (!defined('ABSPATH')) { exit; }

/** Immutable completed-step audit archives. */
final class NC_Step_Archive {
 const OPTION='new_coordinator_step_archives_v1';

 public static function activate(){
  if(false===get_option(self::OPTION,false)) add_option(self::OPTION,array(),'','no');
 }

 public static function all(){ return (array)get_option(self::OPTION,array()); }

 public static function archive($step_id,$title,$final_result,$evidence_refs=array(),$actor_type=null,$actor_id=null){
  $id=sanitize_text_field((string)$step_id); if($id==='') return new WP_Error('nc_archive_step','Step ID is required.');
  $all=self::all(); if(isset($all[$id])) return new WP_Error('nc_archive_immutable','Completed step archive already exists and is immutable.');
  $events=array_values(array_filter(NC_Store::log_entries(),function($e)use($id){return isset($e['step_id'])&&$e['step_id']===$id;}));
  $loops=NC_Loop_State::for_step($id); $failures=0;$restarts=0;
  foreach($loops as $loop){$failures+=(int)($loop['failure_count']??0);$restarts+=(int)($loop['restart_count']??0);}
  $refs=array();foreach((array)$evidence_refs as $ref){$v=sanitize_text_field((string)$ref);if($v!=='')$refs[]=$v;}
  $row=array(
   'step_id'=>$id,'title'=>sanitize_text_field((string)$title),'status'=>'COMPLETED',
   'completed_utc'=>gmdate('c'),'final_result'=>sanitize_text_field((string)$final_result),
   'failure_occurrences'=>$failures,'restart_occurrences'=>$restarts,'loops'=>$loops,
   'events'=>$events,'evidence_refs'=>array_values(array_unique($refs))
  );
  $all[$id]=$row; update_option(self::OPTION,$all,false);
  NC_Store::log('STEP_ARCHIVED','Completed step audit history archived.',$actor_type,$actor_id,array('step_id'=>$id,'event_count'=>count($events),'failure_occurrences'=>$failures,'restart_occurrences'=>$restarts));
  return $row;
 }
}
