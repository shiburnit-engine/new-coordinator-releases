<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Stable Learning registry normalizer.
 *
 * Creates an append-only identity/provenance projection from legacy/local
 * Learning without rewriting the source Learning history.
 */
final class NC_Learning_Normalizer {
 const SCHEMA_VERSION = 1;
 const PREFIX = 'LRN';

 public static function required_record_fields(){
  return array('lesson_id','scope','classification','source_path','source_section','source_locator','summary','provenance_evidence','status','created_utc');
 }

 public static function normalize($source_path,$learning,$existing_registry=array(),$scope='LOCAL'){
  if(!is_string($source_path)||trim($source_path)===''||!is_array($learning))
   return new WP_Error('nc_learning_normalizer_input','Learning normalizer requires a source path and structured Learning.');

  $records=self::records_from_registry($existing_registry);
  $index=self::source_index($records);
  $next=self::next_sequence($records,$scope);
  $added=array();

  foreach($learning as $section=>$entries){
   if(!is_array($entries)) continue;
   $position=0;
   foreach($entries as $entry){
    $position++;
    $locator=$section.'['.$position.']';
    $key=$source_path.'|'.$locator;
    if(isset($index[$key])) continue;

    $summary=self::summary($entry);
    if($summary==='') continue;

    $lesson_id=sprintf('%s-%s-%04d',self::PREFIX,self::clean_scope($scope),$next++);
    $record=array(
     'lesson_id'=>$lesson_id,
     'scope'=>self::clean_scope($scope),
     'classification'=>self::classify($section,$summary),
     'source_path'=>$source_path,
     'source_section'=>(string)$section,
     'source_locator'=>$locator,
     'summary'=>$summary,
     'provenance_evidence'=>array('source_path'=>$source_path,'source_locator'=>$locator),
     'status'=>'ACTIVE',
     'created_utc'=>gmdate('c')
    );
    $records[]=$record;
    $index[$key]=$lesson_id;
    $added[]=$lesson_id;
   }
  }

  return array(
   'schema_version'=>self::SCHEMA_VERSION,
   'source_preserved'=>true,
   'records'=>$records,
   'added_lesson_ids'=>$added,
   'total_records'=>count($records),
   'independent_validation_required'=>true
  );
 }

 private static function records_from_registry($registry){
  if(isset($registry['records'])&&is_array($registry['records'])) return $registry['records'];
  return array();
 }

 private static function source_index($records){
  $out=array();
  foreach($records as $record){
   if(!is_array($record)) continue;
   $path=$record['source_path']??'';
   $locator=$record['source_locator']??'';
   if($path!==''&&$locator!=='') $out[$path.'|'.$locator]=$record['lesson_id']??true;
  }
  return $out;
 }

 private static function next_sequence($records,$scope){
  $max=0; $prefix=self::PREFIX.'-'.self::clean_scope($scope).'-';
  foreach($records as $record){
   $id=is_array($record)?($record['lesson_id']??''):'';
   if(strpos($id,$prefix)!==0) continue;
   $n=(int)substr($id,strlen($prefix));
   if($n>$max) $max=$n;
  }
  return $max+1;
 }

 private static function clean_scope($scope){
  $scope=strtoupper(preg_replace('/[^A-Za-z0-9]+/','-',trim((string)$scope)));
  return trim($scope,'-')?:'LOCAL';
 }

 private static function summary($entry){
  if(is_string($entry)) return trim($entry);
  if(!is_array($entry)) return '';
  foreach(array('rule','problem','lesson','summary','solution','evidence') as $key)
   if(isset($entry[$key])&&is_scalar($entry[$key])&&trim((string)$entry[$key])!=='') return trim((string)$entry[$key]);
  return wp_json_encode($entry);
 }

 private static function classify($section,$summary){
  $text=strtolower($section.' '.$summary);
  if(strpos($text,'security')!==false||strpos($text,'secret')!==false||strpos($text,'auth')!==false) return 'SECURITY';
  if(strpos($text,'test')!==false||strpos($text,'acceptance')!==false||strpos($text,'ci ')!==false) return 'TESTING';
  if(strpos($text,'wordpress')!==false||strpos($text,'plugin')!==false||strpos($text,'wp-')!==false) return 'WORDPRESS';
  if(strpos($text,'runtime')!==false||strpos($text,'endpoint')!==false||strpos($text,'live ')!==false) return 'RUNTIME';
  if(strpos($text,'provider')!==false||strpos($text,'gemini')!==false||strpos($text,'openai')!==false) return 'PROVIDER';
  if(strpos($text,'build')!==false||strpos($text,'package')!==false||strpos($text,'zip')!==false) return 'BUILD';
  if(strpos($section,'lessons_reusable_rules')!==false) return 'REUSABLE';
  return 'PROCESS';
 }
}
