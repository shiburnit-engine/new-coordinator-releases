<?php
if (!defined('ABSPATH')) { exit; }

/** Idempotent install/upgrade initialization for active-plugin replacement. */
final class NC_Upgrade {
 const SCHEMA_OPTION='new_coordinator_schema_version';
 const SCHEMA_VERSION=1;

 public static function maybe_upgrade(){
  $before=(int)get_option(self::SCHEMA_OPTION,0);
  self::ensure_option(NC_Store::STATE,NC_Store::defaults());
  self::ensure_option(NC_Store::LOG,array());
  self::ensure_option(NC_Store::LOG_SEQUENCE,0);
  self::ensure_option(NC_Store::CURRENT_FEATURE,array());
  self::ensure_option(NC_Store::RECORDS,array(
   'research'=>array(),'knowledge'=>array(),'learning'=>array(),'planning'=>array(),'tests'=>array(),'evidence'=>array(),
   'attempts'=>array(),'hypotheses'=>array(),'dependencies'=>array(),'platforms'=>array(),'secrets_metadata'=>array(),
   'variables'=>array(),'chats'=>array(),'checkpoints'=>array()
  ));
  self::ensure_option(NC_Loop_State::OPTION,array());
  self::ensure_option(NC_Plan_State::OPTION,array());
  self::ensure_option(NC_Step_Archive::OPTION,array());
  self::ensure_option(NC_Access::OPTION,NC_Access::defaults());

  // These are idempotent: they preserve existing durable state and only create missing records.
  NC_Loop_State::activate();
  NC_Plan_State::activate();
  NC_Step_Archive::activate();

  // RM-011: explicit durable current Feature; never infer it from registry order.
  if(empty(NC_Store::current_feature()['feature_id'])) NC_Store::select_feature('RM-011','Active NC-001 dashboard Feature during foundation Step 7 acceptance.');

  // Never overwrite or re-lock an existing confirmed owner during an upgrade.
  $owner_raw=get_option(NC_Owner_Setup::OPTION,false);
  if(false===$owner_raw){
   add_option(NC_Owner_Setup::OPTION,NC_Owner_Setup::defaults(),'','no');
   NC_Owner_Setup::detect_proposed_owner();
  }

  if($before<self::SCHEMA_VERSION){
   update_option(self::SCHEMA_OPTION,self::SCHEMA_VERSION,false);
   NC_Store::log('SCHEMA_UPGRADED','New Coordinator storage schema initialized or upgraded.','system','new-coordinator',array('from_schema'=>$before,'to_schema'=>self::SCHEMA_VERSION));
  }
 }
 private static function ensure_option($name,$default){
  if(false===get_option($name,false)) add_option($name,$default,'','no');
 }
}
