<?php
if (!defined('ABSPATH')) { exit; }

/** Durable, auditable planned-substep progress for each Coordinator step. */
final class NC_Plan_State {
 const OPTION='new_coordinator_plan_state_v1';
 const STATUSES=array('NOT_STARTED','ACTIVE','WAITING','FAILED','REBUILDING','TESTING','COMPLETED');

 public static function activate(){
  if(false===get_option(self::OPTION,false)) add_option(self::OPTION,array(),'','no');
  if(!self::get('NC-001')){
   self::create('NC-001','Foundation Controls',array(
    array('id'=>'NC-001-01','title'=>'Research and design','status'=>'COMPLETED'),
    array('id'=>'NC-001-02','title'=>'Define foundation requirements','status'=>'COMPLETED'),
    array('id'=>'NC-001-03','title'=>'Build durable loop telemetry','status'=>'COMPLETED'),
    array('id'=>'NC-001-04','title'=>'Validate telemetry candidate in CI','status'=>'COMPLETED'),
    array('id'=>'NC-001-05','title'=>'Build protected live telemetry endpoint','status'=>'COMPLETED'),
    array('id'=>'NC-001-06','title'=>'Build durable planned-step progress','status'=>'ACTIVE'),
    array('id'=>'NC-001-07','title'=>'Build live Work Viewer','status'=>'NOT_STARTED'),
    array('id'=>'NC-001-08','title'=>'Build live Step Log','status'=>'NOT_STARTED'),
    array('id'=>'NC-001-09','title'=>'Build Log tab, per-step accordions and local search','status'=>'NOT_STARTED'),
    array('id'=>'NC-001-10','title'=>'Build idempotent upgrade and migration handling','status'=>'NOT_STARTED'),
    array('id'=>'NC-001-11','title'=>'Run security tests','status'=>'NOT_STARTED'),
    array('id'=>'NC-001-12','title'=>'Run staging and regression tests','status'=>'NOT_STARTED'),
    array('id'=>'NC-001-13','title'=>'Acceptance and close NC-001','status'=>'NOT_STARTED')
   ),'system','new-coordinator');
  }
 }

 private static function clean_status($status){
  $status=strtoupper(sanitize_key((string)$status));
  return in_array($status,self::STATUSES,true)?$status:'NOT_STARTED';
 }
 public static function all(){ return (array)get_option(self::OPTION,array()); }
 public static function get($step_id){
  $all=self::all(); $id=sanitize_text_field((string)$step_id);
  return isset($all[$id])&&is_array($all[$id])?$all[$id]:null;
 }
 public static function create($step_id,$title,$items,$actor_type=null,$actor_id=null){
  $id=sanitize_text_field((string)$step_id); if($id==='') return new WP_Error('nc_plan_step','Step ID is required.');
  $all=self::all(); if(isset($all[$id])) return new WP_Error('nc_plan_exists','Step plan already exists.');
  $clean=array(); $seen=array();
  foreach((array)$items as $i=>$item){
   $sid=sanitize_text_field((string)($item['id']??($id.'-'.($i+1))));
   if($sid===''||isset($seen[$sid])) return new WP_Error('nc_plan_substep','Each planned substep requires a unique ID.');
   $seen[$sid]=true;
   $clean[]=array('id'=>$sid,'title'=>sanitize_text_field((string)($item['title']??$sid)),'status'=>self::clean_status($item['status']??'NOT_STARTED'),'updated_utc'=>gmdate('c'));
  }
  $row=array('step_id'=>$id,'title'=>sanitize_text_field((string)$title),'revision'=>1,'substeps'=>$clean,'created_utc'=>gmdate('c'),'updated_utc'=>gmdate('c'));
  $all[$id]=$row; update_option(self::OPTION,$all,false);
  NC_Store::log('STEP_PLAN_CREATED','Durable build plan created.',$actor_type,$actor_id,array('step_id'=>$id,'revision'=>1,'substep_count'=>count($clean)));
  return $row;
 }
 public static function revise($step_id,$title,$items,$reason,$actor_type=null,$actor_id=null,$request_key=''){
  $id=sanitize_text_field((string)$step_id); $reason=sanitize_text_field((string)$reason); $request_key=sanitize_key((string)$request_key);
  if($id===''||$reason===''||$request_key==='') return new WP_Error('nc_plan_revision','Step ID, revision reason and request key are required.');
  $all=self::all(); if(!isset($all[$id])||!is_array($all[$id])) return new WP_Error('nc_plan_missing','Step plan does not exist.');
  $current=$all[$id];
  if(($current['revision_request_key']??'')===$request_key) return $current;
  foreach((array)($current['history']??array()) as $prior) if(($prior['revision_request_key']??'')===$request_key) return new WP_Error('nc_plan_revision_stale_replay','This revision request was already applied and later superseded.'); $clean=array(); $seen=array();
  foreach((array)$items as $i=>$item){
   $sid=sanitize_text_field((string)($item['id']??($id.'-'.($i+1))));
   if($sid===''||isset($seen[$sid])) return new WP_Error('nc_plan_substep','Each planned substep requires a unique ID.');
   $seen[$sid]=true;
   $clean[]=array('id'=>$sid,'title'=>sanitize_text_field((string)($item['title']??$sid)),'status'=>self::clean_status($item['status']??'NOT_STARTED'),'updated_utc'=>gmdate('c'));
  }
  if(!$clean) return new WP_Error('nc_plan_revision_empty','A revised plan requires at least one substep.');
  $history=isset($current['history'])&&is_array($current['history'])?$current['history']:array();
  $history[]=array('revision'=>(int)($current['revision']??1),'title'=>(string)($current['title']??''),'substeps'=>(array)($current['substeps']??array()),'created_utc'=>(string)($current['created_utc']??''),'updated_utc'=>(string)($current['updated_utc']??''),'revision_request_key'=>(string)($current['revision_request_key']??''),'superseded_utc'=>gmdate('c'),'superseded_reason'=>$reason,'revised_by_actor_type'=>sanitize_key((string)$actor_type),'revised_by_actor_id'=>sanitize_text_field((string)$actor_id));
  $revision=max(1,(int)($current['revision']??1))+1;
  $row=array('step_id'=>$id,'title'=>sanitize_text_field((string)$title),'revision'=>$revision,'revision_request_key'=>$request_key,'substeps'=>$clean,'history'=>$history,'created_utc'=>(string)($current['created_utc']??gmdate('c')),'updated_utc'=>gmdate('c'));
  $all[$id]=$row; update_option(self::OPTION,$all,false);
  NC_Store::log('STEP_PLAN_REVISED','Durable build plan revised without rewriting prior revision history.',$actor_type,$actor_id,array('step_id'=>$id,'old_revision'=>$revision-1,'new_revision'=>$revision,'old_substep_count'=>count((array)($current['substeps']??array())),'new_substep_count'=>count($clean),'reason'=>$reason,'revision_request_key'=>$request_key,'actor_type'=>sanitize_key((string)$actor_type),'actor_id'=>sanitize_text_field((string)$actor_id)));
  return $row;
 }
 public static function set_status($step_id,$substep_id,$status,$actor_type=null,$actor_id=null){
  $id=sanitize_text_field((string)$step_id); $sid=sanitize_text_field((string)$substep_id); $new=self::clean_status($status);
  $all=self::all(); if(!isset($all[$id])) return new WP_Error('nc_plan_missing','Step plan does not exist.');
  $found=false;$old='';
  foreach($all[$id]['substeps'] as &$item) if($item['id']===$sid){$found=true;$old=$item['status'];$item['status']=$new;$item['updated_utc']=gmdate('c');break;} unset($item);
  if(!$found) return new WP_Error('nc_plan_substep_missing','Planned substep does not exist.');
  $all[$id]['updated_utc']=gmdate('c'); update_option(self::OPTION,$all,false);
  if($old!==$new) NC_Store::log('STEP_PLAN_STATUS','Planned build substep status changed.',$actor_type,$actor_id,array('step_id'=>$id,'substep_id'=>$sid,'old_status'=>$old,'new_status'=>$new));
  return $all[$id];
 }
 public static function revise_nc001_v2(){
  $row=self::get('NC-001');
  if(!$row) return new WP_Error('nc_plan_missing','NC-001 plan does not exist.');
  if((int)($row['revision']??1)>=2) return $row;
  return self::revise('NC-001','Build & Verify the New Coordinator Foundation',array(
   array('id'=>'NC-001-01','title'=>'Research and design the foundation','status'=>'COMPLETED'),
   array('id'=>'NC-001-02','title'=>'Define foundation requirements','status'=>'COMPLETED'),
   array('id'=>'NC-001-03','title'=>'Build durable loop telemetry','status'=>'COMPLETED'),
   array('id'=>'NC-001-04','title'=>'Validate telemetry candidate in CI','status'=>'COMPLETED'),
   array('id'=>'NC-001-05','title'=>'Build protected live telemetry endpoint','status'=>'COMPLETED'),
   array('id'=>'NC-001-06','title'=>'Build durable planned-step progress and auditable revisions','status'=>'COMPLETED'),
   array('id'=>'NC-001-07','title'=>'Build human-friendly live Coordinator dashboard','status'=>'ACTIVE'),
   array('id'=>'NC-001-08','title'=>'Build Feature registry, manifests and searchable ownership markers','status'=>'NOT_STARTED'),
   array('id'=>'NC-001-09','title'=>'Keep detailed audit history and search on the Log tab','status'=>'NOT_STARTED'),
   array('id'=>'NC-001-10','title'=>'Build protected active Debug tab and safe copyable report','status'=>'NOT_STARTED'),
   array('id'=>'NC-001-11','title'=>'Enforce testing-loop Debug contract','status'=>'NOT_STARTED'),
   array('id'=>'NC-001-12','title'=>'Prove live incremental log behavior with bounded runtime test seam','status'=>'NOT_STARTED'),
   array('id'=>'NC-001-13','title'=>'Build and verify idempotent upgrade/migration handling','status'=>'NOT_STARTED'),
   array('id'=>'NC-001-14','title'=>'Run Security Gate tests','status'=>'NOT_STARTED'),
   array('id'=>'NC-001-15','title'=>'Run staging and regression tests','status'=>'NOT_STARTED'),
   array('id'=>'NC-001-16','title'=>'Acceptance, Known-Good checkpoint and close NC-001','status'=>'NOT_STARTED')
  ),'Owner-approved requirements added dashboard Features Debug and testing-loop diagnostics.','system','new-coordinator','nc001-revision-2');
 }
 public static function projection($step_id){
  $row=self::get($step_id);
  if(!$row) return array('step_id'=>sanitize_text_field((string)$step_id),'title'=>'','revision'=>0,'substeps'=>array(),'completed'=>0,'total'=>0,'percent'=>0);
  $done=0; foreach($row['substeps'] as $item) if($item['status']==='COMPLETED') $done++;
  $total=count($row['substeps']); $percent=$total?(int)floor(($done/$total)*100):0;
  return array('step_id'=>$row['step_id'],'title'=>$row['title'],'revision'=>(int)$row['revision'],'substeps'=>$row['substeps'],'completed'=>$done,'total'=>$total,'percent'=>$percent,'formula'=>'completed_substeps / total_substeps');
 }
}
