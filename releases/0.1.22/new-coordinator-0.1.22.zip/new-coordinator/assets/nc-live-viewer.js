(function(){
'use strict';
var cfg=window.NCLive||{},timer=null,failures=0,cursor=0,seen=new Set();
function health(v){text('nc-live-health',v);}
document.querySelectorAll('#nc-live-log-body tr[data-event-id], .nc-step-event[data-event-id]').forEach(function(r){var id=r.getAttribute('data-event-id');if(id)seen.add(id);cursor=Math.max(cursor,Number(r.getAttribute('data-sequence'))||0);});
function text(id,v){var e=document.getElementById(id);if(e)e.textContent=v==null?'':String(v);}
function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];});}
function plan(p){
 if(!p)return;
 text('nc-build-percent',p.percent+'%');
 var bar=document.getElementById('nc-progress-bar');if(bar)bar.style.width=p.percent+'%';
 text('nc-progress-formula',p.completed+' of '+p.total+' planned steps completed');
 text('nc-feature-steps',p.completed+' of '+p.total+' complete');
 var gauge=document.getElementById('nc-progress-gauge');if(gauge)gauge.setAttribute('aria-valuenow',p.percent);
 var list=document.getElementById('nc-plan-list');if(list)list.innerHTML=(p.substeps||[]).map(function(x){return '<li data-status="'+esc(x.status)+'"><strong>'+esc(x.status)+'</strong> — '+esc(x.id+' '+x.title)+'</li>';}).join('');
}
function loops(d){
 var s=d.summary||{};var e=document.getElementById('nc-loop-summary');
 if(e)e.innerHTML='<p>'+esc('Total '+(s.total||0)+' · Active '+(s.active||0)+' · Completed '+(s.completed||0)+' · Failures '+(s.failures||0)+' · Restarts '+(s.restarts||0)+' · Waiting '+(s.waiting||0))+'</p>';
 var det=document.getElementById('nc-loop-details');if(det)det.innerHTML=(d.loops||[]).map(function(x){
  var deps=(x.dependencies||[]).map(function(y){return y.loop_id+' ('+y.state+')';}).join(', ');
  return '<p><strong>'+esc(x.loop_id)+'</strong> — '+esc(x.state)+' — '+esc(x.current_action||'')+(deps?' — Waiting/dependencies: '+esc(deps):'')+'</p>';
 }).join('');
}
function features(f){
 if(!f)return;
 var current=f.current||{};
 text('nc-feature-title',f.selection_valid?(current.title||f.selected_feature_id||'Current Feature'):'Current Feature not selected');
 text('nc-feature-counts',(f.completed||0)+' completed · '+(f.total||0)+' total Features');
}
function work(m){
 if(!m)return;
 text('nc-main-cycle',m.cycle||1);text('nc-current-action',m.current_action||'');
 var status=m.emergency_stop?'Stopped':(m.blocker?'Needs attention':String(m.progress||m.status||'').replace(/_/g,' ').toLowerCase().replace(/(^|\\s)\\S/g,function(x){return x.toUpperCase();}));
 text('nc-friendly-status',status);text('nc-status-detail',m.blocker||'No blocker is currently recorded.');
 var need=!!(m.blocker||m.emergency_stop);text('nc-owner-needed',need?'Yes':'No');text('nc-owner-needed-detail',m.blocker||(m.emergency_stop?'Emergency Stop is active.':'Coordinator can continue without owner action right now.'));
}
function nextFromPlan(p){if(!p)return;var next=(p.substeps||[]).find(function(x){return x.status==='NOT_STARTED'||x.status==='WAITING';});text('nc-next-action',next?next.title:'Acceptance and close this feature');}
function applySearch(){var search=document.getElementById('nc-log-search');if(!search)return;var q=search.value.trim().toLowerCase();document.querySelectorAll('.nc-step-panel').forEach(function(p){var hit=!q||(p.getAttribute('data-search')||'').indexOf(q)!==-1;p.classList.toggle('nc-search-hidden',!hit);if(q&&hit)p.open=true;});}
function logs(d){
 var body=document.getElementById('nc-live-log-body');
 var filter=document.getElementById('nc-audit-user'),audit=filter?Number(filter.value)||0:0,accordionChanged=false;
 (d.logs||[]).slice().sort(function(a,b){return (Number(a.sequence)||0)-(Number(b.sequence)||0);}).forEach(function(e){
  cursor=Math.max(cursor,Number(e.sequence)||0);if(!e.event_id||seen.has(e.event_id))return;seen.add(e.event_id);
  if(body && (!audit || (e.actor_type==='wordpress_user' && Number(e.actor_id)===audit))){
   var empty=body.querySelector('tr td[colspan]');if(empty)empty.parentNode.remove();
   var tr=document.createElement('tr');tr.setAttribute('data-event-id',e.event_id);tr.setAttribute('data-sequence',e.sequence||0);tr.setAttribute('data-step-id',e.step_id||'');tr.setAttribute('data-actor-id',e.actor_id||'');
   tr.innerHTML='<td>'+esc(e.display_time||e.utc||'')+'</td><td>'+esc(e.type||'')+'</td><td>'+esc(e.username||'legacy/unknown')+'</td><td>'+esc(e.message||'')+'</td>';
   body.insertBefore(tr,body.firstChild);
  }
  var panel=document.querySelector('.nc-step-panel[data-current="1"][data-step-id="'+String(e.step_id||'').replace(/"/g,'\\\"')+'"]');
  if(panel){
   var pb=panel.querySelector('.nc-step-body'),exists=panel.querySelector('.nc-step-event[data-event-id="'+String(e.event_id).replace(/"/g,'\\\"')+'"]');
   if(pb&&!exists){
    var div=document.createElement('div');div.className='nc-step-event';div.setAttribute('data-event-id',e.event_id);div.setAttribute('data-sequence',e.sequence||0);
    var searchText=((e.type||'')+' '+(e.username||'')+' '+(e.message||'')+' '+JSON.stringify(e.evidence||{})).toLowerCase();div.setAttribute('data-search',searchText);
    div.innerHTML='<strong>'+esc(e.type||'')+'</strong> — '+esc(e.message||'')+'<small>'+esc((e.display_time||e.utc||'')+' · '+(e.username||'legacy/unknown')+((e.evidence&&e.evidence.loop_id)?' · '+e.evidence.loop_id:''))+'</small>';
    pb.appendChild(div);panel.setAttribute('data-search',((panel.getAttribute('data-search')||'')+' '+searchText).trim());accordionChanged=true;
   }
  }
 });
 if(Number(d.log_cursor)>cursor)cursor=Number(d.log_cursor);if(accordionChanged)applySearch();
}
async function refresh(){
 if(document.hidden)return;
 try{
  var r=await fetch(cfg.url+'?after_sequence='+encodeURIComponent(cursor)+'&t='+Date.now(),{credentials:'same-origin',cache:'no-store',headers:{'X-WP-Nonce':cfg.nonce||''}});
  if(!r.ok){var he=new Error('HTTP');he.ncCategory='HTTP';he.ncStatus=r.status;throw he;}
  var d;try{d=await r.json();}catch(parseError){var pe=new Error('RESPONSE');pe.ncCategory='RESPONSE';throw pe;}
  if(!d||!d.main||!d.plan||!d.features){var se=new Error('SHAPE');se.ncCategory='RESPONSE';throw se;}
  failures=0;health('Live · '+(d.server_display_time||''));work(d.main);features(d.features);plan(d.plan);nextFromPlan(d.plan);loops(d);logs(d);
 }catch(e){failures++;var category=e&&e.ncCategory?e.ncCategory:'NETWORK';var detail=category==='HTTP'&&e.ncStatus?'HTTP '+e.ncStatus:(category==='RESPONSE'?'Invalid live response':'Browser connection failed');health((failures>1?'Live problem · ':'Checking live connection · ')+detail);}
}
function schedule(){if(timer)clearInterval(timer);timer=setInterval(refresh,Math.max(2000,Number(cfg.interval)||3000));}
var search=document.getElementById('nc-log-search');if(search)search.addEventListener('input',applySearch);
document.addEventListener('visibilitychange',function(){if(!document.hidden)refresh();});
refresh();schedule();
})();