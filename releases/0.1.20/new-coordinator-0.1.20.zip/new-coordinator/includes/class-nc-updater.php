<?php
if (!defined('ABSPATH')) { exit; }

/**
 * RM-035: New Coordinator self-contained release updater foundation.
 *
 * Fail closed until a New Coordinator release channel and public verification key
 * are explicitly configured. This class has no dependency on legacy Coordinator plugins.
 */
final class NC_Updater {
    const SLUG = 'new-coordinator';
    const PLUGIN_FILE = 'new-coordinator/new-coordinator.php';
    const CACHE_KEY = 'new_coordinator_verified_update_v1';
    const PACKAGE_CACHE_PREFIX = 'new_coordinator_verified_package_';

    // Intentionally unconfigured during bootstrap. Never point these at the legacy Coordinator channel.
    const METADATA_URL = 'https://raw.githubusercontent.com/shiburnit-engine/new-coordinator-releases/main/update.json';
    const RELEASE_PREFIX = 'https://raw.githubusercontent.com/shiburnit-engine/new-coordinator-releases/main/releases/';
    const PUBLIC_KEY = '4QFmwyqr0lg2P6BQydEkKiZ2Pj1FxEdSeDIOItI8ajc=';

    public static function boot() {
        add_filter('pre_set_site_transient_update_plugins', array(__CLASS__, 'offer_update'));
        add_filter('plugins_api', array(__CLASS__, 'plugin_information'), 20, 3);
        add_filter('upgrader_pre_download', array(__CLASS__, 'verify_download'), 10, 4);
    }

    public static function configured() {
        return self::METADATA_URL !== '' && self::RELEASE_PREFIX !== '' && self::PUBLIC_KEY !== '';
    }

    public static function diagnostic_status() {
        $status = array(
            'installed_version' => defined('NC_VERSION') ? NC_VERSION : '',
            'configured' => self::configured(),
            'sodium_available' => function_exists('sodium_crypto_sign_verify_detached'),
            'ok' => false,
        );
        if (!self::configured()) {
            $status['state'] = 'RELEASE_CHANNEL_NOT_CONFIGURED';
            return $status;
        }
        $metadata = self::get_verified_metadata(true);
        if (is_wp_error($metadata)) {
            $status['state'] = 'VERIFICATION_FAILED';
            $status['error_code'] = $metadata->get_error_code();
            return $status;
        }
        $status['ok'] = true;
        $status['state'] = 'VERIFIED';
        $status['available_version'] = $metadata['version'];
        return $status;
    }

    public static function offer_update($transient) {
        if (!is_object($transient) || !self::configured()) return $transient;
        $metadata = self::get_verified_metadata();
        if (is_wp_error($metadata) || version_compare(self::base_version(), $metadata['version'], '>=')) {
            if (isset($transient->response[self::PLUGIN_FILE])) unset($transient->response[self::PLUGIN_FILE]);
            return $transient;
        }
        set_site_transient(self::package_cache_key($metadata['package_url']), $metadata, 30 * MINUTE_IN_SECONDS);
        $transient->response[self::PLUGIN_FILE] = self::build_offer($metadata);
        return $transient;
    }

    public static function plugin_information($result, $action, $args) {
        if ('plugin_information' !== $action || !is_object($args) || self::SLUG !== ($args->slug ?? '') || !self::configured()) return $result;
        $metadata = self::get_verified_metadata();
        if (is_wp_error($metadata)) return $result;
        return (object) array(
            'name'=>'New Coordinator','slug'=>self::SLUG,'version'=>$metadata['version'],
            'requires'=>$metadata['requires'],'requires_php'=>$metadata['requires_php'],'tested'=>$metadata['tested'],
            'last_updated'=>$metadata['published_at'],'download_link'=>$metadata['package_url'],
            'sections'=>array('description'=>'A verified New Coordinator release.')
        );
    }

    public static function verify_download($reply, $package, $upgrader, $hook_extra) {
        if (!empty($reply) || self::PLUGIN_FILE !== ($hook_extra['plugin'] ?? '')) return $reply;
        if (!self::configured()) return new WP_Error('nc_update_channel_unconfigured', 'New Coordinator release channel is not configured.');
        $metadata = get_site_transient(self::package_cache_key($package));
        if (!is_array($metadata) || !isset($metadata['package_url']) || !hash_equals((string)$metadata['package_url'], (string)$package)) {
            $metadata = self::get_verified_metadata(true);
            if (is_wp_error($metadata)) return $metadata;
            if (!hash_equals((string)$metadata['package_url'], (string)$package)) return new WP_Error('nc_update_package_mismatch', 'New Coordinator blocked an unrecognized update package.');
        }
        $tmp = download_url($package, 300);
        if (is_wp_error($tmp)) return $tmp;
        $actual = hash_file('sha256', $tmp);
        if (!is_string($actual) || !hash_equals((string)$metadata['package_sha256'], strtolower($actual))) {
            wp_delete_file($tmp);
            return new WP_Error('nc_update_checksum_failed', 'New Coordinator blocked an update whose checksum did not match verified metadata.');
        }
        return $tmp;
    }

    public static function get_verified_metadata($force=false) {
        if (!self::configured()) return new WP_Error('nc_update_channel_unconfigured', 'New Coordinator release channel is not configured.');
        if (!$force) {
            $cached = get_site_transient(self::CACHE_KEY);
            if (is_array($cached)) return $cached;
        }
        $response = wp_safe_remote_get(self::METADATA_URL, array('timeout'=>15,'redirection'=>0,'headers'=>array('Accept'=>'application/json')));
        if (is_wp_error($response)) return $response;
        if (200 !== wp_remote_retrieve_response_code($response)) return new WP_Error('nc_update_metadata_unavailable', 'New Coordinator update metadata is unavailable.');
        $verified = self::validate_metadata(json_decode(wp_remote_retrieve_body($response), true));
        if (is_wp_error($verified)) return $verified;
        set_site_transient(self::CACHE_KEY, $verified, 15 * MINUTE_IN_SECONDS);
        return $verified;
    }

    public static function validate_metadata($metadata) {
        $fields = array('schema_version','slug','version','package_url','package_sha256','requires','requires_php','tested','published_at');
        if (!is_array($metadata) || !isset($metadata['signature'])) return new WP_Error('nc_update_metadata_invalid', 'New Coordinator update metadata is incomplete.');
        $signed = array();
        foreach ($fields as $field) {
            if (!array_key_exists($field,$metadata) || !is_scalar($metadata[$field])) return new WP_Error('nc_update_metadata_invalid', 'New Coordinator update metadata is incomplete.');
            $signed[$field] = $metadata[$field];
        }
        if (1 !== $signed['schema_version'] || self::SLUG !== $signed['slug'] || !preg_match('/^\d+\.\d+\.\d+$/',(string)$signed['version'])) return new WP_Error('nc_update_metadata_invalid', 'New Coordinator update metadata has invalid identity or version fields.');
        if (!preg_match('/^[a-f0-9]{64}$/',(string)$signed['package_sha256']) || !str_starts_with((string)$signed['package_url'], self::RELEASE_PREFIX)) return new WP_Error('nc_update_metadata_invalid', 'New Coordinator update metadata has an invalid package location or checksum.');
        if (!function_exists('sodium_crypto_sign_verify_detached')) return new WP_Error('nc_update_signature_unavailable', 'Ed25519 verification is unavailable.');
        $sig=base64_decode((string)$metadata['signature'],true); $key=base64_decode(self::PUBLIC_KEY,true);
        $payload=wp_json_encode($signed,JSON_UNESCAPED_SLASHES);
        if (false===$sig || false===$key || !is_string($payload) || !sodium_crypto_sign_verify_detached($sig,$payload,$key)) return new WP_Error('nc_update_signature_failed','New Coordinator blocked update metadata with an invalid signature.');
        return $signed;
    }

    private static function build_offer($m) {
        return (object) array('id'=>self::SLUG,'slug'=>self::SLUG,'plugin'=>self::PLUGIN_FILE,'new_version'=>$m['version'],'package'=>$m['package_url'],'requires'=>$m['requires'],'requires_php'=>$m['requires_php'],'tested'=>$m['tested']);
    }
    private static function package_cache_key($package) { return self::PACKAGE_CACHE_PREFIX.hash('sha256',$package); }
    private static function base_version() { return preg_replace('/-candidate$/','',defined('NC_VERSION')?NC_VERSION:'0.0.0'); }
}
