<?php
if (!defined('ABSPATH')) { exit; }
final class NC_Store {
 const STATE='new_coordinator_state_v1';
 const LOG='new_coordinator_step_log_v1';
 const RECORDS='new_coordinator_records_v1';
 const LOG_SEQUENCE='new_coordinator_step_log_sequence_v1';
 const CURRENT_FEATURE='new_coordinator_current_feature_v1';
 const DEBUG='new_coordinator_debug_v1';
 const DEBUG_DISPOSITIONS='new_coordinator_debug_dispositions_v1';
 public static function defaults(){ return array(
  'foundation_spec_version'=>1,'project_mode'=>'NEW_PROJECT','status'=>'FOUNDATION_SPECIFIED_NOT_IMPLEMENTED',
  'objective'=>'Build and prove secure portable Gemini Communicator','main_loop_cycle'=>1,'main_loop_stage'=>'FOUNDATION_BUILD',
  'step_id'=>'NC-001','inner_loop_id'=>'IL-NC-001-FOUNDATION','current_action'=>'Build and verify portable foundation controls',
  'progress'=>'CANDIDATE','blocker'=>'','known_good_build'=>'NOT_YET_CREATED','emergency_stop'=>false,'updated_utc'=>gmdate('c')
 );}
 public static function activate(){
  if(false===get_option(self::STATE,false)) add_option(self::STATE,self::defaults(),'','no');
  if(false===get_option(self::LOG,false)) add_option(self::LOG,array(),'','no');
  if(false===get_option(self::LOG_SEQUENCE,false)) add_option(self::LOG_SEQUENCE,0,'','no');
  if(false===get_option(self::DEBUG,false)) add_option(self::DEBUG,array(),'','no');
  if(false===get_option(self::DEBUG_DISPOSITIONS,false)) add_option(self::DEBUG_DISPOSITIONS,array(),'','no');
  if(false===get_option(self::RECORDS,false)) add_option(self::RECORDS,array(
   'research'=>array(),'knowledge'=>array(),'learning'=>array(),'planning'=>array(),'tests'=>array(),'evidence'=>array(),
   'attempts'=>array(),'hypotheses'=>array(),'dependencies'=>array(),'platforms'=>array(),'secrets_metadata'=>array(),
   'variables'=>array(),'chats'=>array(),'checkpoints'=>array()
  ),'','no');
  self::log('PLUGIN_ACTIVATED','New Coordinator candidate activated.','system','new-coordinator');
 }
 public static function state(){ return wp_parse_args((array)get_option(self::STATE,array()),self::defaults()); }
 public static function update_state($changes){
  $s=self::state(); $allowed=array('status','main_loop_stage','step_id','inner_loop_id','current_action','progress','blocker','known_good_build','emergency_stop');
  foreach($allowed as $k) if(array_key_exists($k,$changes)) $s[$k]=is_bool($changes[$k])?$changes[$k]:sanitize_text_field((string)$changes[$k]);
  $s['updated_utc']=gmdate('c'); update_option(self::STATE,$s,false); return $s;
 }
 public static function current_feature(){
  $v=get_option(self::CURRENT_FEATURE,array());
  return is_array($v)?$v:array();
 }
 public static function select_feature($feature_id,$reason=''){
  $id=strtoupper(sanitize_text_field((string)$feature_id));
  if(!preg_match('/^RM-[0-9]{3}$/',$id)) return new WP_Error('invalid_feature_id','Invalid Feature ID.');
  $old=self::current_feature(); if(($old['feature_id']??'')===$id) return $old;
  $row=array('feature_id'=>$id,'selected_utc'=>gmdate('c'),'reason'=>sanitize_text_field((string)$reason));
  update_option(self::CURRENT_FEATURE,$row,false);
  self::log('FEATURE_SELECTED','Current Feature selection changed.','system','new-coordinator',array('feature_id'=>$id,'previous_feature_id'=>$old['feature_id']??'','reason'=>$row['reason']));
  return $row;
 }
 public static function actor(){
  $u=wp_get_current_user();
  if($u && $u->exists()) return array('actor_type'=>'wordpress_user','actor_id'=>(string)$u->ID,'username'=>$u->user_login);
  return array('actor_type'=>'system','actor_id'=>'new-coordinator','username'=>'new-coordinator');
 }
 public static function log($type,$message,$actor_type=null,$actor_id=null,$evidence=array()){
  $log=(array)get_option(self::LOG,array()); $a=self::actor();
  if($actor_type!==null) $a['actor_type']=sanitize_key($actor_type);
  if($actor_id!==null){ $a['actor_id']=sanitize_text_field((string)$actor_id); $a['username']=sanitize_text_field((string)$actor_id); }
  $safe=array(); foreach((array)$evidence as $k=>$v) if(is_scalar($v)||is_null($v)) $safe[sanitize_key($k)]=sanitize_text_field((string)$v);
  $seq=max(0,(int)get_option(self::LOG_SEQUENCE,0))+1;
  update_option(self::LOG_SEQUENCE,$seq,false);
  $state=self::state();
  $step_id=isset($safe['step_id'])&&$safe['step_id']!==''?$safe['step_id']:sanitize_text_field((string)($state['step_id']??''));
  $log[]=array('event_id'=>'nc-event-'.$seq,'sequence'=>$seq,'step_id'=>$step_id,'utc'=>gmdate('c'),'type'=>sanitize_key($type),'actor_type'=>$a['actor_type'],'actor_id'=>$a['actor_id'],
   'username'=>sanitize_user($a['username'],true),'message'=>sanitize_text_field($message),'evidence'=>$safe);
  update_option(self::LOG,$log,false);
 }
 public static function log_entries(){
  $log=(array)get_option(self::LOG,array()); $legacy=0;
  foreach($log as $i=>&$e){
   if(!isset($e['sequence'])){$legacy++;$e['sequence']=-1000000+$legacy;}
   if(empty($e['event_id']))$e['event_id']='legacy-'.hash('sha256',wp_json_encode(array($i,$e['utc']??'',$e['type']??'',$e['message']??'')));
   if(!isset($e['step_id']))$e['step_id']=isset($e['evidence']['step_id'])?sanitize_text_field((string)$e['evidence']['step_id']):'LEGACY_UNASSIGNED';
  } unset($e);
  return $log;
 }
 public static function redact_debug_value($value){
  $text=(string)$value;
  $patterns=array(
   '/-----BEGIN [^-]*PRIVATE KEY-----[\\s\\S]*?-----END [^-]*PRIVATE KEY-----/i',
   '/\\b(?:api[_-]?key|token|secret|password|authorization)\\s*[:=]\\s*[^\\s,;]+/i',
   '/\\bBearer\\s+[A-Za-z0-9._~+\\/=\\-]+/i'
  );
  foreach($patterns as $pattern) $text=preg_replace($pattern,'[REDACTED]',$text);
  return sanitize_textarea_field($text);
 }
 public static function debug_log_path(){
  if(defined('WP_DEBUG_LOG') && is_string(WP_DEBUG_LOG) && WP_DEBUG_LOG!=='') return WP_DEBUG_LOG;
  return defined('WP_CONTENT_DIR') ? trailingslashit(WP_CONTENT_DIR).'debug.log' : '';
 }
 public static function read_debug_log($max_bytes=262144){
  $path=self::debug_log_path();
  if($path==='' || !is_readable($path)) return array('path_available'=>false,'bytes_read'=>0,'truncated'=>false,'entries'=>array());
  $size=(int)@filesize($path); $max=max(4096,min(1048576,(int)$max_bytes)); $start=max(0,$size-$max);
  $fh=@fopen($path,'rb'); if(!$fh) return array('path_available'=>false,'bytes_read'=>0,'truncated'=>false,'entries'=>array());
  if($start>0) @fseek($fh,$start); $raw=(string)stream_get_contents($fh); fclose($fh);
  if($start>0){$p=strpos($raw,"\n");if($p!==false)$raw=substr($raw,$p+1);}
  $raw=self::redact_debug_value($raw);
  $lines=preg_split('/\\R/',$raw); $entries=array();
  foreach($lines as $line){$line=trim($line);if($line==='')continue;$severity='INFO';if(preg_match('/PHP (Fatal error|Parse error)|Uncaught /i',$line))$severity='CRITICAL';elseif(preg_match('/PHP (Warning|Deprecated)|Warning:|Deprecated:/i',$line))$severity='WARNING';elseif(preg_match('/PHP Notice|Notice:/i',$line))$severity='NOTICE';$entries[]=array('severity'=>$severity,'message'=>$line,'signature'=>hash('sha256',preg_replace('/\\d+/','#',strtolower($line))));}
  return array('path_available'=>true,'bytes_read'=>strlen($raw),'truncated'=>$start>0,'entries'=>$entries);
 }
 public static function classify_debug_entry($entry){
  $severity=strtoupper((string)($entry['severity']??'INFO'));
  if($severity==='CRITICAL') return 'FIX_NOW';
  if($severity==='WARNING') return 'FIX_LATER';
  return 'REVIEW';
 }
 public static function reset_debug_log($reason='owner_reset'){
  $path=self::debug_log_path();
  if($path==='' || !is_file($path) || !is_writable($path)) return new WP_Error('debug_log_not_writable','WordPress debug log is not available for reset.');
  $fh=@fopen($path,'c'); if(!$fh) return new WP_Error('debug_log_open_failed','WordPress debug log could not be opened for reset.');
  $ok=false; if(@flock($fh,LOCK_EX)){ $ok=@ftruncate($fh,0); @fflush($fh); @flock($fh,LOCK_UN); } fclose($fh);
  if(!$ok) return new WP_Error('debug_log_reset_failed','WordPress debug log could not be reset safely.');
  self::log('DEBUG_LOG_RESET','WordPress/PHP debug log reset after explicit authorized action.','system','new-coordinator',array('reason'=>sanitize_text_field((string)$reason)));
  return true;
 }
 public static function debug_dispositions(){ $v=get_option(self::DEBUG_DISPOSITIONS,array()); return is_array($v)?$v:array(); }
 public static function set_debug_disposition($signature,$disposition,$reason='',$evidence=''){
  $signature=sanitize_text_field((string)$signature); $disposition=strtoupper(sanitize_key((string)$disposition));
  if(!in_array($disposition,array('FIX_NOW','FIX_LATER','IGNORE'),true) || $signature==='') return false;
  if($disposition==='IGNORE' && (trim((string)$reason)==='' || trim((string)$evidence)==='')) return false;
  $all=self::debug_dispositions(); $all[$signature]=array('disposition'=>$disposition,'reason'=>self::redact_debug_value($reason),'evidence'=>self::redact_debug_value($evidence),'updated_utc'=>gmdate('c'));
  update_option(self::DEBUG_DISPOSITIONS,$all,false); self::log('DEBUG_DISPOSITION_SET','Debug issue disposition recorded.','system','new-coordinator',array('signature'=>$signature,'disposition'=>$disposition)); return true;
 }
 public static function site_debug_issues(){
  $scan=self::read_debug_log(); $disp=self::debug_dispositions(); $issues=array();
  foreach($scan['entries'] as $entry){$sig=$entry['signature'];$saved=$disp[$sig]??array();$d=$saved['disposition']??self::classify_debug_entry($entry);$entry['disposition']=$d;$entry['reason']=$saved['reason']??'';$issues[]=$entry;}
  $scan['issues']=$issues; unset($scan['entries']); return $scan;
 }
 public static function debug_entries(){
  $rows=get_option(self::DEBUG,array()); return is_array($rows)?array_values($rows):array();
 }
 public static function add_debug($code,$summary,$details='',$component='',$evidence=array()){
  $rows=self::debug_entries(); $id='DBG-'.str_pad((string)(count($rows)+1),4,'0',STR_PAD_LEFT);
  $safe=array(); foreach((array)$evidence as $k=>$v) if(is_scalar($v)||is_null($v)) $safe[sanitize_key($k)]=self::redact_debug_value($v);
  $rows[]=array('debug_id'=>$id,'status'=>'ACTIVE','created_utc'=>gmdate('c'),'code'=>sanitize_key($code),'summary'=>self::redact_debug_value($summary),'details'=>self::redact_debug_value($details),'component'=>sanitize_text_field($component),'evidence'=>$safe);
  update_option(self::DEBUG,$rows,false);
  self::log('DEBUG_OPENED','Active diagnostic record created.','system','new-coordinator',array('debug_id'=>$id,'code'=>sanitize_key($code)));
  return $id;
 }
 public static function resolve_debug($debug_id,$resolution=''){
  $rows=self::debug_entries(); $found=false;
  foreach($rows as &$row) if(($row['debug_id']??'')===$debug_id && ($row['status']??'')==='ACTIVE'){$row['status']='RESOLVED';$row['resolved_utc']=gmdate('c');$row['resolution']=self::redact_debug_value($resolution);$found=true;break;} unset($row);
  if(!$found) return false;
  update_option(self::DEBUG,$rows,false);
  self::log('DEBUG_RESOLVED','Diagnostic record resolved and removed from active Debug view.','system','new-coordinator',array('debug_id'=>$debug_id));
  return true;
 }
 public static function active_debug_entries(){ return array_values(array_filter(self::debug_entries(),function($r){return ($r['status']??'')==='ACTIVE';})); }
 public static function display_time($utc){
  try { $dt=new DateTimeImmutable($utc,new DateTimeZone('UTC')); $format=trim((string)get_option('date_format').' '.(string)get_option('time_format')); if($format==='') $format='Y-m-d H:i'; return wp_date($format,$dt->getTimestamp(),wp_timezone()); }
  catch(Exception $e){ return sanitize_text_field((string)$utc); }
 }
}
