<?php
if (!defined('ABSPATH')) { exit; }
/**
 * WordPress debug-mode state used by the one-time wp-config.php bootstrap.
 * The bootstrap reads wp-content/new-coordinator-debug-mode.php before
 * WordPress loads and defines WP_DEBUG/WP_DEBUG_LOG/WP_DEBUG_DISPLAY.
 */
final class NC_Debug_Mode {
 const STATE_FILE='new-coordinator-debug-mode.php';
 const BOOTSTRAP_BEGIN='/* NEW COORDINATOR DEBUG BOOTSTRAP BEGIN */';
 const BOOTSTRAP_END='/* NEW COORDINATOR DEBUG BOOTSTRAP END */';
 public static function state_path(){ return trailingslashit(WP_CONTENT_DIR).self::STATE_FILE; }
 public static function bootstrap_snippet(){
  return self::BOOTSTRAP_BEGIN."\n".
   "\$nc_debug_state = __DIR__ . '/wp-content/".self::STATE_FILE."';\n".
   "if (is_readable(\$nc_debug_state)) { require \$nc_debug_state; }\n".
   "if (!defined('WP_DEBUG')) define('WP_DEBUG', false);\n".
   "if (!defined('WP_DEBUG_LOG')) define('WP_DEBUG_LOG', false);\n".
   "if (!defined('WP_DEBUG_DISPLAY')) define('WP_DEBUG_DISPLAY', false);\n".
   self::BOOTSTRAP_END."\n";
 }
 public static function config_path(){ return dirname(ABSPATH).'/wp-config.php'; }
 public static function bootstrap_status(){
  $path=self::config_path(); if(!is_readable($path)) return array('installed'=>false,'writable'=>false,'verified'=>false);
  $body=(string)@file_get_contents($path); $installed=strpos($body,self::BOOTSTRAP_BEGIN)!==false && strpos($body,self::BOOTSTRAP_END)!==false;
  return array('installed'=>$installed,'writable'=>is_writable($path),'verified'=>$installed && strpos($body,"$nc_debug_state = __DIR__ . '/wp-content/".self::STATE_FILE."';")!==false);
 }
 public static function install_bootstrap(){
  if(!NC_Access::is_owner()) return new WP_Error('not_owner','Only the Coordinator owner may install the Debug bootstrap.');
  $path=self::config_path(); if(!is_readable($path)||!is_writable($path)) return new WP_Error('config_not_writable','wp-config.php is not readable and writable.');
  $original=(string)@file_get_contents($path); if(strpos($original,self::BOOTSTRAP_BEGIN)!==false) return self::bootstrap_status();
  $anchor="/* That's all, stop editing! Happy publishing. */"; $pos=strpos($original,$anchor); if($pos===false) return new WP_Error('bootstrap_anchor_missing','Safe wp-config.php insertion anchor was not found.');
  $backup=$path.'.nc-debug-backup-'.gmdate('YmdHis'); if(!@copy($path,$backup)) return new WP_Error('config_backup_failed','Could not create wp-config.php backup.');
  $updated=substr($original,0,$pos).self::bootstrap_snippet()."\n".substr($original,$pos); $tmp=$path.'.nc-debug.tmp';
  if(@file_put_contents($tmp,$updated,LOCK_EX)===false || !@rename($tmp,$path)){@unlink($tmp);return new WP_Error('bootstrap_write_failed','Could not atomically install Debug bootstrap.');}
  $check=(string)@file_get_contents($path); if(strpos($check,self::BOOTSTRAP_BEGIN)===false || strpos($check,self::BOOTSTRAP_END)===false){@copy($backup,$path);return new WP_Error('bootstrap_verify_failed','Bootstrap verification failed; wp-config.php backup restored.');}
  NC_Store::log('DEBUG_BOOTSTRAP_INSTALLED','Owner installed one-time WordPress Debug bootstrap.','system','new-coordinator',array('backup_created'=>true));
  return self::bootstrap_status();
 }
 public static function effective(){
  return array(
   'wp_debug'=>defined('WP_DEBUG')?(bool)WP_DEBUG:false,
   'wp_debug_log'=>defined('WP_DEBUG_LOG')?WP_DEBUG_LOG:false,
   'wp_debug_display'=>defined('WP_DEBUG_DISPLAY')?(bool)WP_DEBUG_DISPLAY:false,
   'managed_state_present'=>is_file(self::state_path()),
   'bootstrap'=>self::bootstrap_status()
  );
 }
 public static function write_state($enabled){
  if(!NC_Access::is_owner()) return new WP_Error('not_owner','Only the Coordinator owner may change Debug Mode.');
  $status=self::bootstrap_status();
  if(empty($status['verified'])) return new WP_Error('debug_bootstrap_not_verified','The one-time Debug bootstrap must be installed and verified before changing managed Debug Mode.');
  $enabled=(bool)$enabled;
  $body="<?php\n/* Managed by New Coordinator. No secrets. */\n".
   "if (!defined('WP_DEBUG')) define('WP_DEBUG', ".($enabled?'true':'false').");\n".
   "if (!defined('WP_DEBUG_LOG')) define('WP_DEBUG_LOG', ".($enabled?'true':'false').");\n".
   "if (!defined('WP_DEBUG_DISPLAY')) define('WP_DEBUG_DISPLAY', false);\n";
  $path=self::state_path(); $tmp=$path.'.tmp';
  if(@file_put_contents($tmp,$body,LOCK_EX)===false) return new WP_Error('debug_state_write_failed','Could not write the protected Debug Mode state.');
  @chmod($tmp,0640);
  if(!@rename($tmp,$path)){@unlink($tmp);return new WP_Error('debug_state_commit_failed','Could not commit the protected Debug Mode state.');}
  $check=(string)@file_get_contents($path);
  if(strpos($check,"define('WP_DEBUG', ".($enabled?'true':'false').")")===false || strpos($check,"define('WP_DEBUG_DISPLAY', false)")===false) return new WP_Error('debug_state_verify_failed','Debug Mode state verification failed.');
  NC_Store::log('DEBUG_MODE_CHANGED','Owner changed managed WordPress Debug Mode.','system','new-coordinator',array('enabled'=>$enabled));
  return true;
 }
}
