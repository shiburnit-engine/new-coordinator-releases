<?php
/**
 * Plugin Name: New Coordinator
 * Description: Portable loop-first Coordinator foundation.
 * Version: 0.1.21-candidate
 * Requires PHP: 8.1
 */
if (!defined('ABSPATH')) { exit; }
define('NC_VERSION','0.1.21-candidate');
define('NC_DIR',plugin_dir_path(__FILE__));
require_once NC_DIR.'includes/class-nc-store.php';
require_once NC_DIR.'includes/class-nc-loop-state.php';
require_once NC_DIR.'includes/class-nc-instruction-gate.php';
require_once NC_DIR.'includes/class-nc-learning-normalizer.php';
require_once NC_DIR.'includes/class-nc-loop-builder-learning.php';
require_once NC_DIR.'includes/class-nc-loop-builder.php';
require_once NC_DIR.'includes/class-nc-plan-state.php';
require_once NC_DIR.'includes/class-nc-step-archive.php';
require_once NC_DIR.'includes/class-nc-owner-setup.php';
require_once NC_DIR.'includes/class-nc-access.php';
require_once NC_DIR.'includes/class-nc-live.php';
require_once NC_DIR.'includes/class-nc-acceptance.php';
require_once NC_DIR.'includes/class-nc-upgrade.php';
require_once NC_DIR.'includes/class-nc-updater.php';
require_once NC_DIR.'includes/class-nc-key-generator.php';
require_once NC_DIR.'includes/class-nc-admin.php';
function nc_activate_candidate(){
 NC_Store::activate();
 NC_Loop_State::activate();
 NC_Plan_State::activate();
 NC_Step_Archive::activate();
 $owner=NC_Owner_Setup::detect_proposed_owner();
 if(NC_Owner_Setup::is_locked()){
  NC_Store::update_state(array(
   'status'=>'SETUP_LOCKED',
   'progress'=>'LOCKED',
   'current_action'=>'Coordinator owner confirmation required before operational access.'
  ));
 }
}
register_activation_hook(__FILE__,'nc_activate_candidate');
add_action('plugins_loaded',function(){ NC_Upgrade::maybe_upgrade(); NC_Updater::boot(); NC_Live::boot(); NC_Acceptance::boot(); NC_Admin::boot(); });
